"""Agent mode: AccessLoop repairs a page on its own, inside a policy a person sets, and stops for what only a person knows.

    perceive (scan) -> plan (fix proposals) -> policy gate -> act (write) -> verify (independent re-scan)
        -> commit, or roll back -> re-plan on the new page -> ... -> hand over (summary + questions for the person)

The policy is the human approval given in advance: which risk levels the agent may apply on its own, which rules are off
limits, how many changes it may make, and when it must stop (circuit breaker). Anything that needs words only a person
knows (alt text, names, titles) is never guessed: it is handed back as a question. Every step is in the audit log, and
the run itself is recorded with its policy, so a reviewer can see what the agent was allowed to do and what it did.
"""
from __future__ import annotations
import time
from dataclasses import dataclass, field, asdict

from .workflow import Workflow, WorkflowError


@dataclass
class Policy:
    risks: tuple = ('low',)                 # risk levels the agent may apply without asking ('low', 'medium')
    deny_rules: tuple = ()                  # rules the agent must never touch
    max_changes: int = 200                  # most writes in one run
    stop_after_rollbacks: int = 6           # circuit breaker: stop after this many rollbacks in a row
    batch: bool = True                      # apply identical fixes together (one write, one re-scan)

    def allows(self, p) -> tuple[bool, str]:
        if p.needs_input:
            return False, 'needs words only a person knows'
        if p.rule_id in self.deny_rules:
            return False, 'rule is off limits in this policy'
        if p.risk not in self.risks:
            return False, f'{p.risk}-risk fixes need a person in this policy'
        return True, ''

    def describe(self) -> str:
        parts = [f'applies {" and ".join(self.risks)}-risk automatic fixes', f'at most {self.max_changes} changes',
                 f'stops after {self.stop_after_rollbacks} rollbacks in a row']
        if self.deny_rules:
            parts.append('never touches ' + ', '.join(self.deny_rules))
        return '; '.join(parts) + '; never types text for you.'


@dataclass
class Step:
    n: int
    phase: str                  # perceive | plan | gate | act | verify | commit | rollback | escalate | stop
    title: str
    detail: str = ''
    rule: str = ''
    size: int = 0
    violations: int | None = None
    seconds: float = 0.0


@dataclass
class Run:
    policy: Policy
    steps: list = field(default_factory=list)
    before: int = 0
    after: int = 0
    reviews_before: int = 0
    reviews_after: int = 0
    applied: int = 0            # individual fixes kept
    decisions: int = 0          # writes (a batch counts once)
    rolled_back: int = 0
    held: list = field(default_factory=list)        # proposals the policy kept for a person
    questions: list = field(default_factory=list)   # fixes that need typed text
    stopped: str = ''
    seconds: float = 0.0

    def to_dict(self) -> dict:
        d = asdict(self)
        d['policy_text'] = self.policy.describe()
        return d


def run(engine: Workflow, policy: Policy | None = None, reviewer: str = 'AccessLoop agent', language: str = 'en',
        on_step=None) -> Run:
    """Repair the loaded page within `policy`. `on_step(step, run)` is called after every step (for live display)."""
    policy = policy or Policy()
    if not engine.loaded:
        raise WorkflowError('Load a page first.')
    r = Run(policy=policy)
    t_start = time.perf_counter()

    def step(phase, title, detail='', rule='', size=0, seconds=0.0):
        s = Step(len(r.steps) + 1, phase, title, detail, rule, size,
                 len(engine.current_scan.findings) if engine.current_scan else None, round(seconds, 2))
        r.steps.append(s)
        if on_step:
            on_step(s, r)
        return s

    engine._event('agent_started', 'Agent run started. Policy: ' + policy.describe(), reviewer=reviewer,
                  policy=asdict(policy))
    t = time.perf_counter()
    scan = engine.current_scan or engine.scan(language=language)
    r.before, r.reviews_before = len(scan.findings), len(scan.reviews)
    step('perceive', f'Scanned the page: {r.before} violations, {r.reviews_before} items that need checking',
         seconds=time.perf_counter() - t)
    step('plan', f'Planned {len(engine.proposals)} fixes', f'{sum(p.needs_input for p in engine.proposals)} need words '
         'from a person')

    failed: set = set()          # (rule, selector, before, line) that did not verify
    single: set = set()          # rules whose batch was rolled back: try one by one
    streak = 0
    while True:
        if r.decisions >= policy.max_changes:
            r.stopped = f'Reached the limit of {policy.max_changes} changes.'
            break
        if streak >= policy.stop_after_rollbacks:
            r.stopped = f'Circuit breaker: {streak} rollbacks in a row.'
            break
        allowed, held = [], {}
        for p in engine.proposals:
            if (p.rule_id, p.selector, p.before, p.line) in failed:
                continue
            ok, why = policy.allows(p)
            (allowed.append(p) if ok else held.setdefault(p.proposal_id, (p, why)))
        if not allowed:
            break
        groups: dict[str, list] = {}
        for p in allowed:
            groups.setdefault(p.rule_id, []).append(p)
        batch = None
        if policy.batch:
            batch = next((g for rule, g in groups.items() if len(g) >= 2 and rule not in single), None)
        todo = batch or [allowed[0]]
        rule, n = todo[0].rule_id, len(todo)
        step('gate', f'Policy allows {n} “{rule}” fix{"es" if n > 1 else ""}', f'risk {todo[0].risk}; '
             + ('one write for all of them' if n > 1 else todo[0].selector), rule, n)
        t = time.perf_counter()
        try:
            if n > 1:
                out = engine.apply_batch([p.proposal_id for p in todo], language=language, reviewer=reviewer)
            else:
                out = engine.apply(todo[0].proposal_id, approved=True, language=language, reviewer=reviewer)
            status, detail = out.status, out.detail
        except WorkflowError as error:
            status, detail = 'refused', str(error)
        r.decisions += 1
        secs = time.perf_counter() - t
        step('act', f'Wrote the change to the working copy', detail='original file untouched', rule=rule, size=n)
        if status == 'verified':
            r.applied += n
            streak = 0
            step('commit', f'Verified and kept: {n} fix{"es" if n > 1 else ""}', detail, rule, n, secs)
        else:
            r.rolled_back += 1
            streak += 1
            if n > 1:
                single.add(rule)
            else:
                p = todo[0]
                failed.add((p.rule_id, p.selector, p.before, p.line))
            step('rollback', 'Did not verify, so it was undone' if status == 'rolled_back' else 'Refused before writing',
                 detail, rule, n, secs)
    # hand over to the person
    for p in engine.proposals:
        ok, why = policy.allows(p)
        if p.needs_input:
            r.questions.append({'id': p.proposal_id, 'rule': p.rule_id, 'selector': p.selector, 'line': p.line,
                                'question': p.explanation, 'fields': [dict(f) for f in p.fields]})
        elif not ok:
            r.held.append({'id': p.proposal_id, 'rule': p.rule_id, 'selector': p.selector, 'line': p.line, 'why': why})
    cur = engine.current_scan
    r.after, r.reviews_after = len(cur.findings), len(cur.reviews)
    r.seconds = round(time.perf_counter() - t_start, 2)
    if r.questions or r.held:
        step('escalate', f'Handed {len(r.questions) + len(r.held)} fixes to you',
             f'{len(r.questions)} need your words, {len(r.held)} need your approval')
    step('stop', r.stopped or 'Nothing more the agent may do on its own',
         f'{r.before} → {r.after} violations, {r.applied} fixes kept, {r.rolled_back} rolled back, {r.seconds} s')
    engine._event('agent_finished', f'Agent run finished: {r.before} → {r.after} violations; {r.applied} fixes kept in '
                  f'{r.decisions} writes; {r.rolled_back} rolled back; {len(r.questions)} questions and {len(r.held)} '
                  f'held fixes handed to a person.' + (f' {r.stopped}' if r.stopped else ''), reviewer=reviewer,
                  violations_before=r.before, violations_after=r.after, applied=r.applied, rolled_back=r.rolled_back,
                  questions=len(r.questions), held=len(r.held), seconds=r.seconds)
    return r
