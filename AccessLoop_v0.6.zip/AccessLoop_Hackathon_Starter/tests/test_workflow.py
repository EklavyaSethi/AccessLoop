import re
import pytest
from accessloop.workflow import Workflow, WorkflowError
from accessloop.planner import sha256
from accessloop.models import Finding, ScanResult
from conftest import fake_scanner


def test_complete_three_issue_loop(tmp_path, source):
    engine = Workflow(tmp_path, scanner=fake_scanner)
    engine.load(source)
    result = engine.scan()
    assert len(result.findings) == 3
    assert {p.rule_id for p in engine.proposals} == {'html-has-lang', 'label', 'button-name'}
    for _ in range(3):
        proposal = engine.proposals[0]
        outcome = engine.apply(proposal.proposal_id, approved=True)
        assert outcome.status == 'verified', outcome.detail
    assert len(engine.current_scan.findings) == 0
    assert sha256((tmp_path/'original.html').read_text()) == sha256(source)
    assert len(list((tmp_path/'backups').glob('*.html'))) == 3
    assert engine.report_json().count('verified') >= 3


def test_rejected_edits_do_not_write(tmp_path, source):
    engine = Workflow(tmp_path, scanner=fake_scanner)
    engine.load(source)
    engine.scan()
    original_hash = sha256(engine.current_html)
    outcome = engine.reject(engine.proposals[0].proposal_id)
    assert outcome.status == 'rejected'
    assert sha256(engine.current_html) == original_hash
    assert not (tmp_path/'backups').exists()


def test_no_approval_means_no_write(tmp_path, source):
    engine = Workflow(tmp_path, scanner=fake_scanner)
    engine.load(source)
    engine.scan()
    outcome = engine.apply(engine.proposals[0].proposal_id, approved=False)
    assert outcome.status == 'rejected'
    assert engine.current_html == source


def test_stale_proposal_blocked(tmp_path, source):
    engine = Workflow(tmp_path, scanner=fake_scanner)
    engine.load(source)
    engine.scan()
    stale = engine.proposals[-1]
    engine.apply(engine.proposals[0].proposal_id, approved=True)
    with pytest.raises(WorkflowError):
        engine.apply(stale.proposal_id, approved=True)


def test_regression_rolls_back_and_preserves_hash(tmp_path, source):
    def new_regression_after_patch(html):
        base = fake_scanner(html)
        if re.search(r'<html\b[^>]*\blang=', html, re.I):
            return ScanResult(base.findings + (Finding('color-contrast','#fake','serious','bad contrast','regression'),))
        return base
    engine = Workflow(tmp_path, scanner=new_regression_after_patch)
    engine.load(source)
    engine.scan()
    before = sha256(engine.current_html)
    result = engine.apply(engine.proposals[0].proposal_id, approved=True)
    assert result.status == 'rolled_back'
    assert sha256(engine.current_html) == before
    assert engine.events[-1]['event'] == 'rolled_back'


def test_browser_scan_failure_rolls_back(tmp_path, source):
    calls = 0
    def broken_scanner(html):
        nonlocal calls
        calls += 1
        if calls > 1:
            raise RuntimeError('Browser unavailable')
        return fake_scanner(html)
    engine = Workflow(tmp_path, scanner=broken_scanner)
    engine.load(source)
    engine.scan()
    outcome = engine.apply(engine.proposals[0].proposal_id, approved=True)
    assert outcome.status == 'rolled_back'
    assert engine.current_html == source


def test_disallow_active_html(tmp_path, source):
    engine = Workflow(tmp_path, scanner=fake_scanner)
    with pytest.raises(WorkflowError):
        engine.load(source.replace('</body>', '<script>alert(1)</script></body>'))
    with pytest.raises(WorkflowError):
        engine.load(source.replace('<main>', '<main onclick="evil()">'))


def test_ambiguous_icon_not_auto_labeled(tmp_path):
    from pathlib import Path
    source = (Path(__file__).resolve().parent.parent / 'examples/ambiguous_icon_button.html').read_text()
    def ambiguous(_):
        return ScanResult((Finding('button-name','#icon-action','critical','Unnamed button','No clear label'),))
    engine = Workflow(tmp_path, scanner=ambiguous)
    engine.load(source)
    engine.scan()
    assert engine.current_scan.findings[0].rule_id == 'button-name'
    # The agent never invents a name: the only proposal asks the reviewer to type one.
    assert len(engine.proposals) == 1 and engine.proposals[0].needs_input and not engine.proposals[0].new_html
    before = engine.current_html
    with pytest.raises(WorkflowError):
        engine.apply(engine.proposals[0].proposal_id, approved=True)
    assert engine.current_html == before


def test_report_includes_counts_and_events(tmp_path, source):
    import json
    engine = Workflow(tmp_path, scanner=fake_scanner)
    engine.load(source)
    engine.scan()
    data = json.loads(engine.report_json())
    assert data['baseline_counts']['label'] == 1
    assert data['current_sha256'] == sha256(source)
    assert data['audit_events'][0]['event'] == 'loaded'


def test_crlf_preserved_in_backup_and_rejection(tmp_path, source):
    crlf = source.replace('\n', '\r\n')
    engine = Workflow(tmp_path, scanner=fake_scanner)
    engine.load(crlf)
    engine.scan()
    engine.reject(engine.proposals[0].proposal_id)
    assert engine.current_html == crlf
    assert (tmp_path / 'working.html').read_bytes() == crlf.encode()
