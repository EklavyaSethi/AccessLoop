"""AccessLoop Streamlit app (multi-page). Launch:  streamlit run app.py

Pages live in streamlit_ui/views. All logic is in accessloop.web.server.Session (also used by the local web UI and tested).
"""
from __future__ import annotations
from html import escape

import streamlit as st

from streamlit_ui import nav, theme, ui

st.set_page_config(page_title='AccessLoop · Reviewed accessibility repair', page_icon='♿', layout='wide',
                   initial_sidebar_state='expanded')
ui.setup()
try:
    st.logo(str(theme.LOGO_PATH))
except Exception:  # noqa: BLE001 - the logo is cosmetic
    pass

page = st.navigation(nav.build())

with st.sidebar:
    state = ui.session().state()
    if state['loaded']:
        rows = f'<div class="row"><span>File</span><span>{escape(state["source_name"])}</span></div>'
        if state['scanned']:
            m = state['metrics']
            rows += (f'<div class="row"><span>Violations</span><span>{m["baseline"]} → {m["current"]}</span></div>'
                     f'<div class="row"><span>Verified fixes</span><span>{m["verified"]}</span></div>')
        else:
            rows += '<div class="row"><span>Status</span><span>Not scanned</span></div>'
        st.markdown(f'<div class="al-side"><b>Current session</b>{rows}</div>', unsafe_allow_html=True)
    else:
        st.markdown('<div class="al-side"><b>Current session</b>No page loaded yet.</div>', unsafe_allow_html=True)
    st.caption('Runs locally. Page code never leaves this machine.')

page.run()
