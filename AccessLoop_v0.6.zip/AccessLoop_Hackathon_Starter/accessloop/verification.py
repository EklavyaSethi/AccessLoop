"""Treat improvements as local evidence, never as a full WCAG compliance claim."""
from .models import ScanResult


def verify(before: ScanResult, after: ScanResult, target_rule: str) -> tuple[bool, str]:
    old, new = before.counts(), after.counts()
    if new[target_rule] >= old[target_rule]:
        return False, f'Target rule {target_rule} did not improve ({old[target_rule]} → {new[target_rule]}).'
    for rule in set(old) | set(new):
        if new[rule] > old[rule]:
            return False, f'Automated regression: {rule} increased ({old[rule]} → {new[rule]}).'
    return True, f'Target rule improved ({old[target_rule]} → {new[target_rule]}); no increase in detected rule counts.'
