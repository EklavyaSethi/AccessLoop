from __future__ import annotations
import re
from dataclasses import dataclass, asdict, field
from collections import Counter
from typing import Any


@dataclass(frozen=True)
class Finding:
    rule_id: str
    selector: str
    impact: str
    help: str
    description: str
    uid: int | None = None            # exact source element (data-al-uid) when the scan was instrumented
    html: str = ''
    data: Any = field(default=None, compare=False, hash=False)   # axe check data, e.g. colours for contrast


@dataclass(frozen=True)
class ScanResult:
    findings: tuple[Finding, ...]
    incomplete: int = 0
    passed_rules: int = 0

    @classmethod
    def from_axe(cls, data: dict[str, Any]) -> 'ScanResult':
        findings = []
        for violation in data.get('violations', []):
            for node in violation.get('nodes', []):
                targets = node.get('target') or ['(unknown element)']
                checks: dict[str, Any] = {}
                for group in ('any', 'all', 'none'):
                    for check in node.get(group) or []:
                        if check.get('data') is not None:
                            checks[str(check.get('id'))] = check['data']
                raw_uid = node.get('uid')
                findings.append(Finding(
                    rule_id=str(violation['id']),
                    selector=re.sub(r'\[data-al-uid="\d+"\]', '', str(targets[0])),
                    impact=str(violation.get('impact') or 'unknown'),
                    help=str(violation.get('help') or violation['id']),
                    description=str(node.get('failureSummary') or ''),
                    uid=int(raw_uid) if str(raw_uid).isdigit() else None,
                    html=re.sub(r' data-al-uid="\d+"', '', str(node.get('html') or ''))[:400],
                    data=checks or None,
                ))
        return cls(tuple(findings), len(data.get('incomplete', [])), len(data.get('passes', [])))

    def counts(self) -> Counter[str]:
        return Counter(f.rule_id for f in self.findings)


@dataclass(frozen=True)
class Proposal:
    proposal_id: str
    rule_id: str
    selector: str
    explanation: str
    evidence: str
    before: str
    after: str
    base_sha256: str
    new_html: str
    finding_index: int = -1
    uid: int | None = None
    mode: str = 'auto'                # 'auto' or 'input'
    risk: str = 'low'
    fields: tuple = ()                # input mode: what the reviewer must type
    needs_input: bool = False
    line: int | None = None           # 1-based source line of the element


@dataclass(frozen=True)
class Outcome:
    status: str
    detail: str
    before_count: int
    after_count: int

    def to_dict(self) -> dict:
        return asdict(self)
