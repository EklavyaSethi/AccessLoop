"""Real-browser acceptance suite over examples/ + examples/samples/.

Runs every sample through the actual Workflow (Chromium + axe-core), checks the
expected agent behaviour (fix / abstain / refuse), and writes a report.

    python -m accessloop.sample_suite [--out sample_results]
"""
from __future__ import annotations
import argparse
import json
from dataclasses import dataclass, field
from pathlib import Path
from tempfile import TemporaryDirectory
from typing import Callable

from .planner import sha256
from .workflow import Workflow, WorkflowError

ROOT = Path(__file__).resolve().parent.parent
SUPPORTED = ('html-has-lang', 'label', 'button-name')


@dataclass
class CaseResult:
    name: str
    file: str
    purpose: str
    passed: bool = True
    checks: list[tuple[str, bool]] = field(default_factory=list)
    baseline: dict = field(default_factory=dict)
    final: dict = field(default_factory=dict)
    applied: list[dict] = field(default_factory=list)
    manual_queue: list[str] = field(default_factory=list)
    note: str = ''

    def check(self, label: str, ok: bool) -> None:
        self.checks.append((label, bool(ok)))
        self.passed = self.passed and bool(ok)


def typed_values(p, overrides: dict | None = None) -> dict | None:
    """Stand-in for the human reviewer: supplies text for input-mode proposals. Auto proposals need none."""
    if not p.needs_input:
        return None
    over = (overrides or {}).get(p.rule_id, {})
    values: dict = {}
    for fld in p.fields:
        name = fld['name']
        if name in over:
            values[name] = over[name]
        elif fld['kind'] == 'select':
            values[name] = fld['options'][0][0]
        elif fld['kind'] == 'checkbox':
            values[name] = False
        else:
            values[name] = 'Reviewer typed description'
    return values


def _approve_all(engine: Workflow, result: CaseResult, language: str = 'en', limit: int = 40,
                 overrides: dict | None = None) -> None:
    """Approve every proposal once. A proposal that is rolled back is recorded and not retried."""
    tried: set[str] = set()
    for _ in range(limit):
        todo = [p for p in engine.proposals if p.proposal_id not in tried]
        if not todo:
            return
        p = todo[0]
        tried.add(p.proposal_id)
        out = engine.apply(p.proposal_id, approved=True, language=language, values=typed_values(p, overrides))
        result.applied.append({'rule': p.rule_id, 'selector': p.selector, 'status': out.status,
                               'before': p.before, 'after': p.after, 'detail': out.detail})
    result.check('loop terminates within limit', False)


def _finish(engine: Workflow, result: CaseResult, out_dir: Path | None, stem: str) -> None:
    result.final = dict(engine.current_scan.counts())
    result.manual_queue = [f'{f.rule_id} {f.selector}' for f in engine.current_scan.findings]
    if out_dir:
        (out_dir / f'{stem}.repaired.html').write_text(engine.current_html, encoding='utf-8')
        (out_dir / f'{stem}.evidence.json').write_text(engine.report_json(), encoding='utf-8')


def run_case(name: str, file: str, purpose: str, body: Callable[[Workflow, str, CaseResult], None],
             out_dir: Path | None) -> CaseResult:
    path = ROOT / file
    source = path.read_text(encoding='utf-8')
    result = CaseResult(name, file, purpose)
    with TemporaryDirectory() as tmp:
        engine = Workflow(Path(tmp))
        try:
            body(engine, source, result)
            if engine.loaded and engine.current_scan is not None:
                result.check('original.html never modified',
                             sha256((Path(tmp) / 'original.html').read_text(encoding='utf-8')) == sha256(source))
                _finish(engine, result, out_dir, path.stem)
        except Exception as error:  # an unexpected crash is a failed case, not a suite crash
            result.check(f'no unexpected exception ({type(error).__name__}: {error})', False)
    return result


# ---------- case bodies ----------

def seeded_demo(engine, source, r):
    engine.load(source)
    r.baseline = dict(engine.scan().counts())
    r.check('3 seeded rules detected', set(SUPPORTED) <= r.baseline.keys())
    _approve_all(engine, r)
    r.check('every applied patch verified', r.applied and all(a['status'] == 'verified' for a in r.applied))
    r.check('seeded rules cleared', not any(engine.current_scan.counts()[k] for k in SUPPORTED))


def kyc_onboarding(engine, source, r):
    engine.load(source)
    r.baseline = dict(engine.scan().counts())
    r.check('html-has-lang=1, label=4, button-name=1 detected',
            r.baseline.get('html-has-lang') == 1 and r.baseline.get('label') == 4 and r.baseline.get('button-name') == 1)
    r.check('6 proposals generated', len(engine.proposals) == 6)
    # Human rejects first: must not write.
    h = sha256(engine.current_html)
    engine.reject(engine.proposals[0].proposal_id)
    r.check('reject leaves working file byte-identical', sha256(engine.current_html) == h)
    # approved=False is treated as rejection.
    engine.apply(engine.proposals[0].proposal_id, approved=False)
    r.check('approved=False leaves working file byte-identical', sha256(engine.current_html) == h)
    # Stale proposal must be blocked after another edit lands.
    stale = engine.proposals[-1]
    _approve_all(engine, r)
    try:
        engine.apply(stale.proposal_id, approved=True)
        r.check('stale proposal blocked', False)
    except WorkflowError:
        r.check('stale proposal blocked', True)
    r.check('6 patches applied, all verified', len(r.applied) == 6 and all(a['status'] == 'verified' for a in r.applied))
    r.check('total violations reach 0', len(engine.current_scan.findings) == 0)


def kyc_bad_language(engine, source, r):
    engine.load(source)
    r.baseline = dict(engine.scan(language='english').counts())
    r.check('invalid language code -> no html-has-lang proposal',
            not any(p.rule_id == 'html-has-lang' for p in engine.proposals))
    r.check('other proposals still offered', len(engine.proposals) == 5)
    r.note = 'Reviewer language "english" is not a BCP-47 code; agent abstains for that rule only.'


def sip_signup(engine, source, r):
    engine.load(source)
    r.baseline = dict(engine.scan().counts())
    r.check('language, labels, image, link and select problems detected',
            r.baseline.get('html-has-lang') == 1 and r.baseline.get('label') == 2
            and {'image-alt', 'link-name', 'select-name'} <= r.baseline.keys())
    inputs = sorted(p.rule_id for p in engine.proposals if p.needs_input)
    r.check('alt text, link name and select name ask the reviewer (never guessed)',
            inputs == ['image-alt', 'link-name', 'select-name'])
    # Approving an input fix without typing anything must be refused and change nothing.
    h = sha256(engine.current_html)
    first_input = next(p for p in engine.proposals if p.needs_input)
    try:
        engine.apply(first_input.proposal_id, approved=True)
        r.check('input fix without typed text refused', False)
    except WorkflowError:
        r.check('input fix without typed text refused', sha256(engine.current_html) == h)
    _approve_all(engine, r)
    r.check('6 patches, all verified', len(r.applied) == 6 and all(a['status'] == 'verified' for a in r.applied))
    r.check('total violations reach 0', len(engine.current_scan.findings) == 0)


def loan_emi(engine, source, r):
    engine.load(source)
    r.baseline = dict(engine.scan().counts())
    r.check('3 labels and 1 button name detected', r.baseline.get('label') == 3 and r.baseline.get('button-name') == 1)
    btn = [p for p in engine.proposals if p.rule_id == 'button-name']
    r.check('icon-only reset button asks the reviewer instead of guessing', len(btn) == 1 and btn[0].needs_input)
    _approve_all(engine, r, overrides={'button-name': {'text': 'Reset calculator'}})
    r.check('all verified, violations reach 0',
            all(a['status'] == 'verified' for a in r.applied) and not engine.current_scan.findings)


def insurance_claim(engine, source, r):
    engine.load(source)
    r.baseline = dict(engine.scan().counts())
    r.check('language, 3 labels, button name detected',
            r.baseline.get('html-has-lang') == 1 and r.baseline.get('label') == 3 and r.baseline.get('button-name') == 1)
    r.check('already-labelled textarea is not touched', len(engine.proposals) == 5)
    _approve_all(engine, r)
    r.check('5 patches applied, all verified', len(r.applied) == 5 and all(a['status'] == 'verified' for a in r.applied))
    r.check('total violations reach 0', len(engine.current_scan.findings) == 0)


def tricky(engine, source, r):
    engine.load(source)
    r.baseline = dict(engine.scan().counts())
    r.check('label and button-name findings detected', r.baseline.get('label') == 4 and r.baseline.get('button-name') == 3)
    r.check('ambiguous patterns ask the reviewer; clear ones are auto',
            sum(p.needs_input for p in engine.proposals) >= 4 and any(not p.needs_input for p in engine.proposals))
    # A careless reviewer types text that contradicts the visible words on the button.
    bad = next(p for p in engine.proposals if p.rule_id == 'button-name' and 'two-spans' in p.selector)
    h = sha256(engine.current_html)
    out = engine.apply(bad.proposal_id, approved=True, values={'text': 'Cancel everything'})
    r.check('mismatched typed text is rolled back by the re-scan, file unchanged',
            out.status == 'rolled_back' and sha256(engine.current_html) == h)
    _approve_all(engine, r, overrides={'button-name': {'text': 'Confirm transfer'}})
    good = [a for a in r.applied if a['status'] == 'verified']
    r.check('every remaining fix verified or safely rolled back',
            all(a['status'] in ('verified', 'rolled_back') for a in r.applied) and len(good) >= 5)


def gallery(engine, source, r):
    engine.load(source)
    r.baseline = dict(engine.scan().counts())
    r.check('legacy portal has 20+ defects across 15+ rule types',
            sum(r.baseline.values()) >= 20 and len(r.baseline) >= 15)
    r.check('every finding gets a proposal', len(engine.proposals) == sum(r.baseline.values()))
    _approve_all(engine, r, limit=60)
    r.check('every patch verified (none rolled back)', all(a['status'] == 'verified' for a in r.applied))
    r.check('total violations reach 0', len(engine.current_scan.findings) == 0)


def accessible(engine, source, r):
    engine.load(source)
    r.baseline = dict(engine.scan().counts())
    r.check('zero violations on clean page', not r.baseline)
    r.check('zero proposals', engine.proposals == ())


def unsafe(engine, source, r):
    try:
        engine.load(source)
        r.check('script/onclick page refused before scan', False)
    except WorkflowError as error:
        r.check('script/onclick page refused before scan', True)
        r.note = f'Refused: {error}'


def ambiguous_icon(engine, source, r):
    engine.load(source)
    r.baseline = dict(engine.scan().counts())
    r.check('button-name detected', r.baseline.get('button-name') == 1)
    r.check('no invented label: one input proposal, nothing written yet',
            len(engine.proposals) == 1 and engine.proposals[0].needs_input and engine.current_html == source)


CASES = [
    ('Starter demo (regression)', 'examples/student_registration.html', 'Original starter page: 3 seeded rules fixed end-to-end', seeded_demo),
    ('Starter ambiguous icon (regression)', 'examples/ambiguous_icon_button.html', 'Icon-only button asks the reviewer, never guessed', ambiguous_icon),
    ('B1 KYC onboarding', 'examples/samples/01_kyc_onboarding.html', 'Many instances + reject / no-approval / stale guards on a KYC form', kyc_onboarding),
    ('B1b Invalid language', 'examples/samples/01_kyc_onboarding.html', 'Bad reviewer language input', kyc_bad_language),
    ('B2 SIP sign-up', 'examples/samples/02_sip_signup.html', 'Mixed: auto fixes plus three fixes that need reviewer-typed text', sip_signup),
    ('B3 Loan EMI calculator', 'examples/samples/03_loan_emi_calculator.html', 'Labels auto-fixed; icon-only reset button asks the reviewer', loan_emi),
    ('B4 Insurance claim', 'examples/samples/04_insurance_claim.html', 'Claim form fully repaired and verified', insurance_claim),
    ('B5 Payment edge cases', 'examples/samples/05_banking_edge_cases.html', 'Near-miss patterns on a payment form: ask, never guess; bad typed text is rolled back', tricky),
    ('B8 Legacy portal gallery', 'examples/samples/08_legacy_portal_gallery.html', '22 defects across 20 rule types, all fixed and verified', gallery),
    ('B6 Accessible sign-in', 'examples/samples/06_accessible_login.html', 'Clean control page; no false positives / edits', accessible),
    ('B7 Unsafe payment page', 'examples/samples/07_unsafe_payment_page.html', 'Script + inline handler refused at input', unsafe),
]


def to_markdown(results: list[CaseResult]) -> str:
    lines = ['# AccessLoop sample-suite results', '',
             f'**{sum(r.passed for r in results)}/{len(results)} cases passed** '
             '(real Chromium + axe-core, no fake scanner)', '']
    for r in results:
        lines += [f'## {"PASS" if r.passed else "FAIL"} - {r.name}', f'`{r.file}` - {r.purpose}', '']
        if r.baseline or r.final:
            lines.append(f'- Baseline counts: `{r.baseline}`  ->  Final counts: `{r.final}`')
        for a in r.applied:
            lines.append(f'- {a["status"]}: **{a["rule"]}** `{a["selector"]}`  `{a["before"]}` -> `{a["after"]}`')
        if r.manual_queue:
            lines.append(f'- Manual-review queue: {", ".join(f"`{m}`" for m in r.manual_queue)}')
        if r.note:
            lines.append(f'- Note: {r.note}')
        for label, ok in r.checks:
            lines.append(f'  - [{"x" if ok else " "}] {label}')
        lines.append('')
    return '\n'.join(lines)


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument('--out', default='sample_results')
    args = ap.parse_args()
    out = Path(args.out)
    out.mkdir(parents=True, exist_ok=True)
    results = [run_case(n, f, p, b, out) for n, f, p, b in CASES]
    md = to_markdown(results)
    (out / 'RESULTS.md').write_text(md, encoding='utf-8')
    (out / 'results.json').write_text(json.dumps([r.__dict__ for r in results], indent=2, default=str), encoding='utf-8')
    print(md)
    return 0 if all(r.passed for r in results) else 1


if __name__ == '__main__':
    raise SystemExit(main())
