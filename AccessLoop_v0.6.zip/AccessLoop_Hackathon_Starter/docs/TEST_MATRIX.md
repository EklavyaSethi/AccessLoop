# Test matrix and release checklist

| ID | Scenario | Expected | Automation |
|---|---|---|---|
| T01 | Seeded initial scan | Three supported axe rule IDs found | Real-browser smoke |
| T02 | Approve `html-has-lang` | Language added; axe rule decreases | Real-browser smoke |
| T03 | Approve `label` | Existing visible label connected to ID | Unit + smoke |
| T04 | Approve `button-name` | Visible text no longer hidden from accessibility tree | Unit + smoke |
| T05 | Reject candidate | No write; identical source SHA | Unit |
| T06 | Submit `approved=False` | No write | Unit |
| T07 | Reapply stale proposal after another edit | Blocked | Unit |
| T08 | New rule regression after patch | Roll back | Unit |
| T09 | Browser crash or scan exception after patch | Roll back | Unit |
| T10 | Icon-only button with no obvious name | No guessed text; manual queue | Unit + manual browser |
| T11 | Upload contains a script/event handler | Rejected | Unit |
| T12 | Input over 200 KB | Rejected | Manual / unit extension |
| T13 | Missing npm axe dependency | Visible setup instruction, no false success | Manual |
| T14 | No Gemini API key | Clearly reports deterministic fallback | Manual |
| T15 | Export final HTML, evidence JSON | Files download and open | Manual |
| T16 | Reset | Working copy identical to original | Manual |
| T17 | Keyboard-only use of UI | Buttons and review areas keyboard accessible | Manual |
| T18 | Zoom browser to 200% | No critical text clipping | Manual |

## Run before showing judges

```bash
source .venv/bin/activate
python -m pytest -q
python -m accessloop.smoke
streamlit run app.py
```

Record: machine, OS, Python/Node versions, date, exact command outputs, screenshot of initial and final page, issues unresolved. **A passing fake-scanner unit test is not a substitute for passing the real-browser smoke test.**

## Acceptance criteria

1. Three seeded issues demonstrate the complete repair cycle in an actual browser.
2. Zero unauthorized writes for rejects or absent approval.
3. A post-edit scan failure causes rollback.
4. No increased detected violations; target decreases on each successful repair.
5. All unhandled issues appear in a manual-review queue.
6. Team can explain real LLM role vs deterministic fallback without misrepresenting the system.
7. No false "100% WCAG compliant" claim.
