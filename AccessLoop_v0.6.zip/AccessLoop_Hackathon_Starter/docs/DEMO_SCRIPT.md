# 3-minute live judge demonstration

## 0:00–0:25 — Pain point

"Accessibility testing tools are good at telling developers what is wrong. But the developer still has to locate the code, choose a fix, edit the source, and test again. AccessLoop connects those steps, with explicit approval and verification."

Mention 2026 WebAIM 95.9% of sampled homepages with automatically detectable WCAG failures. **This is prevalence, not estimated speed savings.**

## 0:25–0:50 — Scan

Click **Load seeded demo page**, then **Run accessibility scan**. Explain that actual Chromium renders it and locally installed axe-core evaluates WCAG testable rules. Show the three seeded findings.

## 0:50–1:20 — Developer control

Open the label suggestion. Point to the existing visible label and the proposed `for="email"` addition. Click **Reject (no change)** first. Open the audit log to show the rejection and the unchanged file SHA-256. No write is made.

## 1:20–1:55 — Repair and verification

Now click **Approve and verify**. Show: a controlled patch to the working HTML, automatic rescan, the target finding count dropping, and the event marked `verified`. Repeat for page language and unnamed button.

## 1:55–2:20 — Safe refusal

Load `examples/ambiguous_icon_button.html`, scan, show `button-name` with **no automatic patch**. Explain that the agent cannot know whether the icon means 'menu', 'search', or something else; it escalates instead of inventing a label. If time permits, demonstrate LLM contextual triage on the seeded fixes. Be clear if that optional AI feature is offline.

## 2:20–2:40 — Evidence

Download JSON evidence and the revised HTML. Explain that source hash, before/after findings, unresolved issues, approval/rejection history, and regression rollback are recorded.

## 2:40–3:00 — Limits and impact

"This prototype supports static HTML and three safe repair templates. It does not certify that a site meets WCAG. Next we'd add component framework support, broader test coverage and accessibility-user feedback."

## Judge Q&A (use precise claims)

**Why is this agentic and not merely a scanner?** The pipeline plans bounded source actions based on scanner evidence, branches on contextual eligibility, waits for approval, uses a patch tool, independently observes results, and adapts by committing, escalating or rolling back. If Gemini is enabled, it contributes a non-executing semantic review; the state machine enforces safety.

**Why not fix everything with an LLM?** A plausible-looking fix can be wrong. An incorrect screen-reader label can hide the intended meaning. Low-confidence cases are escalated rather than hallucinated.

**Why only three issues?** They are common, easy to reproduce, and permit objective end-to-end verification within eight hours.

**What's different from axe?** axe detects; AccessLoop adds source-level diffs, human approval, guarded writes, rollback and evidence.

**Could it work in production today?** Not yet. The prototype intentionally handles a trusted, single-file static HTML scope. Additional security review, test coverage, framework AST patches, CI integrations and human assistive-tech evaluation are needed.

**What if Wi-Fi fails?** The core browser scanner uses local axe-core and local Chromium; Gemini advice can be skipped. Both packages must have been installed before going offline.

**What if axe gives zero errors?** It proves no violations from the rules axe evaluated in that run, not full accessibility.
