# Architecture and threat boundaries

## Architecture

```
TRUSTED STATIC HTML (200 KB max)
            |
      Streamlit uploader
            |
      Validator / safe workspace
            |
     Chromium + axe-core   <---- Browser blocked from external network resources
            |
      Finding objects (axe rule + DOM selector)
            |
     Rule-specific source context
            |
       Restricted plan tool <---- Optional LLM advisory review
            |
          DIFF
            |
     EXPLICIT DEVELOPER APPROVAL
            |
    SHA / candidate re-validation
            |
     Backup + atomic file write
            |
    INDEPENDENT CHROMIUM/AXE RESCAN
           / \
        PASS  FAIL / ERROR
          |          |
        Commit     Restore pre-edit copy
          |          |
       Audit event and report
```

## What does the agent decide?

The workflow chooses findings eligible for automated correction and abstains from unsupported or ambiguous ones. Templates apply only when source evidence and axe element selectors match. A Gemini classifier can additionally recommend or escalate a candidate based on contextual snippets. **No LLM is the source of truth for validation or file writes.** The state machine performs the tool sequence; the model only advises within strict boundaries. This is more defensible than a chatbot that rewrites whole HTML pages without verification.

## State transition contract

- `UNLOADED → LOADED`: only via validated trusted HTML.
- `LOADED → SCANNED`: real axe result or an explicitly surfaced scan failure.
- `SCANNED → PROPOSED`: only allowlisted rule and uniquely matched source.
- `PROPOSED → REJECTED`: event log only, no file mutation.
- `PROPOSED → PATCHED`: requires developer action + same hash + patch re-validation.
- `PATCHED → VERIFIED`: actual rescan shows target decrease and no rule count increases.
- `PATCHED → ROLLED_BACK`: scan exception or failing rule-count gate; restore previous byte-equivalent text.
- `VERIFIED → SCANNED`: new proposals generated against the updated source.

## File-level contract

The uploaded original is stored separately from the working copy. The user's source file is not overwritten. A successful patch updates `working.html`, makes a backup, and returns a downloadable artifact. A rejected patch never writes. A failing patch is reverted even if the browser scanner crashes. `sha256` detects stale candidate submissions before modification.

## Security and scope

Trusted source only. This is not a security sandbox for arbitrary attacker-controlled HTML. Static scripts, embedded frames and event handlers are rejected; browser external resources are blocked. Local file copies are per Streamlit session. No arbitrary shell execution tools, no unrestricted filesystem paths, no code authored by an LLM is executed. Uploaded source snippets are sent to the remote model **only if the user explicitly clicks AI review and provides an API key**. Credentials must never be sent in prompts.

## Verification limits

The verification gate checks a strict decrease in the targeted axe rule's affected nodes and no increase in affected-node counts on any other axe rule. This protects against many common regressions but cannot detect every structural, semantic, or visual defect; dynamic pages are unsupported. A user must still verify keyboard navigation, focus order, screen reader announcements, meaningful labeling, visual appearance and responsive layout. Full WCAG AA conformance cannot be inferred from an all-green axe result.

## Prioritization

**P0**: Real browser scanner, three seeded fixes, permission gate, rollback, unit + smoke tests.
**P1**: Usable review UI, before/after counts, audit trail, manual-review queue.
**P2**: Optional Gemini reviewer via structured-output JSON.
**P3**: Downloadable evidence JSON, accessibility improvements to the app itself.

Do not replace P0 with P2 when blocked by an AI API quota or connectivity error.
