from __future__ import annotations
import streamlit as st
from .. import ui


def _banner(outcome: dict | None) -> None:
    if not outcome:
        return
    kind = outcome.get('status', '')
    text = {'verified': 'Verified', 'rejected': 'Rejected', 'rolled_back': 'Rolled back'}.get(kind, kind)
    detail = outcome.get('detail', '')
    st.markdown(f'<div class="al-banner {ui.esc(kind)}" role="status"><b>{ui.esc(text)}:</b> {ui.esc(detail)}</div>', unsafe_allow_html=True)


def _inputs(p: dict) -> dict | None:
    """Typed fields for fixes that need words only a person can supply. Nothing is guessed."""
    if not p.get('needs_input'):
        return None
    values: dict = {}
    for i, f in enumerate(p.get('fields', [])):
        key = f'val_{p["id"]}_{i}'
        if f.get('kind') == 'select':
            options = [(v, label) for v, label in f.get('options', [])]
            values[f['name']] = st.selectbox(f['label'], [v for v, _ in options], key=key,
                                             format_func=dict(options).get, help=f.get('help') or None)
        elif f.get('kind') == 'checkbox':
            values[f['name']] = st.checkbox(f['label'], key=key)
        else:
            values[f['name']] = st.text_input(f['label'], key=key, max_chars=f.get('max', 150), help=f.get('help') or None)
    return values


def render() -> None:
    s = ui.session()
    state = s.state()
    ui.page_header('Review repair proposals', 'Nothing is written until you approve. Every fix comes from a fixed template, then the page is re-scanned and the change is undone automatically if anything gets worse.', 3, state)
    ui.need_scanned(state)
    ui.show_flash()
    _banner(state.get('outcome'))
    m = state['metrics']
    ui.metrics([('Waiting for your decision', m['eligible'], ''), ('Verified', m['verified'], 'good'),
                ('Rejected', m['rejected'], ''), ('Rolled back', m['rolled_back'], 'bad' if m['rolled_back'] else '')])
    if not ui.reviewer():
        st.warning('No reviewer name is set. Decisions will be recorded as "not recorded". Add one on the Load page.')

    proposals = state['proposals']
    if not proposals:
        st.success('No more fixes are waiting for review on this page.')
        a, b = st.columns(2)
        with a:
            ui.link('verify', 'See verification results', ':material/verified:')
        with b:
            ui.link('manual', 'Open manual review queue', ':material/assignment_late:')
        ui.footer()
        return

    with st.expander('Optional: ask AI to triage these proposals'):
        st.write('The AI only recommends approving or escalating. It never writes code and never decides the result.')
        if st.button('Request AI review', key='ai_review'):
            try:
                result = s.ai()
            except Exception as error:  # noqa: BLE001
                result = {'available': False, 'message': str(error)}
            (st.success if result['available'] else st.warning)(result['message'])
            if result['available']:
                st.rerun()

    for p in proposals:
        with st.container(border=True):
            tags = ui.badge(p['impact'], p['impact']) + ui.badge(p['rule'], 'neutral')
            if p['wcag']:
                tags += ui.badge('WCAG ' + ', '.join(p['wcag']) + (f' · {p["level"]}' if p['level'] else ''), 'info')
            st.markdown(f'<div><b>{ui.esc(p["title"])}</b></div><div>{tags}</div>', unsafe_allow_html=True)
            st.write(p['explanation'])
            st.caption(f'Element: {p["selector"]}' + (f'  ·  line {p["line"]}' if p.get('line') else '') + f'  ·  Evidence: {p["evidence"]}')
            st.markdown(ui.diff_html(p['diff']), unsafe_allow_html=True)
            if p.get('ai'):
                st.info(f'AI advice: {str(p["ai"].get("verdict", "")).upper()}. {p["ai"].get("reason", "")}')
            values = _inputs(p)
            a, b = st.columns(2)
            if a.button('Approve and verify', key='approve_' + p['id'], type='primary'):
                with st.spinner('Applying the change and re-scanning…'):
                    ok = ui.run(s.approve, p['id'], ui.language(), ui.reviewer(), values)
                if ok:
                    st.rerun()
            if b.button('Reject (no change)', key='reject_' + p['id']):
                if ui.run(s.reject, p['id'], ui.reviewer()):
                    st.rerun()
    ui.footer()
