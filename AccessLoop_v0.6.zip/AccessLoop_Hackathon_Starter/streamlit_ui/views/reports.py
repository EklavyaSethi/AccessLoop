from __future__ import annotations
import streamlit as st
import streamlit.components.v1 as components
from accessloop import catalog as catalog_mod
from accessloop.web import report as report_mod
from .. import ui


def render() -> None:
    s = ui.session()
    state = s.state()
    ui.page_header('Reports and downloads', 'Everything an auditor, a teammate or a regulator-facing reviewer needs, generated from this session.', 5, state)
    ui.need_scanned(state)
    html = report_mod.build_html(s.report_payload())
    base = state['source_name'].rsplit('.', 1)[0] or 'page'

    with st.container(border=True):
        st.subheader('Session reports')
        a, b = st.columns(2)
        a.download_button('Evidence report (HTML, print to PDF)', html, file_name=f'{base}_evidence_report.html', mime='text/html', type='primary')
        b.download_button('Evidence record (JSON)', s.report_json(), file_name=f'{base}_evidence.json', mime='application/json')
        c, d = st.columns(2)
        c.download_button('Repaired page (HTML)', s.file('working'), file_name=f'{base}_repaired.html', mime='text/html')
        d.download_button('Original page (HTML)', s.file('original'), file_name=f'{base}_original.html', mime='text/html')
        st.caption('To make a PDF, open the evidence report in your browser and choose Print, then Save as PDF.')

    with st.container(border=True):
        st.subheader('Issue catalogue')
        e, f = st.columns(2)
        e.download_button('Catalogue (CSV)', catalog_mod.to_csv(s.catalog), file_name='accessloop_issue_catalog.csv', mime='text/csv')
        f.download_button('Catalogue (Markdown)', catalog_mod.to_markdown(s.catalog), file_name='accessloop_issue_catalog.md', mime='text/markdown')

    with st.expander('Preview the evidence report', expanded=True):
        components.html(html, height=900, scrolling=True)
    ui.footer()
