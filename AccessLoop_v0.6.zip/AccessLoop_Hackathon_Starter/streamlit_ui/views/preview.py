from __future__ import annotations
import streamlit as st
import streamlit.components.v1 as components
from .. import ui


def render() -> None:
    s = ui.session()
    state = s.state()
    ui.page_header('Page preview', 'The original and the current working copy side by side. Previews are shown in a locked frame, so scripts and external requests do not run.', None, None)
    ui.need_loaded(state)
    a, b = st.columns(2)
    with a:
        st.subheader('Original')
        components.html(s.file('original'), height=620, scrolling=True)
    with b:
        st.subheader('Current working copy')
        components.html(s.file('working'), height=620, scrolling=True)
    if state['changed']:
        st.success('The working copy differs from the original. See the Audit trail for each change.')
    else:
        st.caption('The working copy is identical to the original.')
    ui.footer()
