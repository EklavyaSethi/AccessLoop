"""Streamlit pages. (1) Smoke test of every page with a stand-in streamlit; (2) real AppTest when Streamlit is installed."""
import importlib
import importlib.util
import sys
from pathlib import Path

import pytest
from accessloop import scanner
import fake_streamlit as fake

HAS_STREAMLIT = importlib.util.find_spec('streamlit') is not None  # evaluated before any stand-in is installed
ROOT = Path(__file__).resolve().parent.parent
needs_axe = pytest.mark.skipif(not scanner.AXE_PATH.is_file(), reason='axe-core not installed (npm install)')
PAGES = ['home', 'load', 'scan', 'review', 'verify', 'manual', 'preview', 'reports', 'audit', 'coverage', 'how']


def render(st, name):
    mod = importlib.import_module(f'streamlit_ui.views.{name}')
    try:
        mod.render()
    except fake.StopScript:
        pass
    return mod


def test_every_page_renders_before_anything_is_loaded():
    st = fake.install()
    st.session_state.clear()
    for name in PAGES:
        render(st, name)
    assert not st.errors


def test_nav_covers_every_view_and_builds():
    st = fake.install()
    from streamlit_ui import nav
    sections = nav.build()
    assert [k for _, k, *_ in nav.SPEC] == PAGES
    assert set(nav.PAGES) == set(PAGES)
    assert list(sections)[0] == '' and 'Workflow' in sections and 'Evidence' in sections and 'Reference' in sections


@needs_axe
def test_full_workflow_through_the_pages():
    st = fake.install(clicks={'load_sample'})
    st.session_state.clear()
    st.session_state['al_language'] = 'en-IN'
    render(st, 'load')  # clicking "Load sample" loads the first sample and reruns
    from streamlit_ui import ui
    s = ui.session()
    assert s.state()['loaded']

    st = fake.install(clicks=set())
    st.session_state['al_session'] = s
    s.load(None, '', 'examples/samples/02_event_feedback.html')
    st.session_state['al_language'] = 'en-IN'
    st.session_state['al_reviewer'] = 'Tester'
    for name in ('load', 'scan', 'manual', 'preview', 'audit', 'coverage', 'how'):
        render(st, name)

    # Scan
    st = fake.install(clicks={'run_scan'})
    st.session_state['al_session'] = s
    st.session_state['al_language'] = 'en-IN'
    render(st, 'scan')
    state = s.state()
    assert state['scanned'] and state['proposals']

    # Review, approve the first proposal
    pid = state['proposals'][0]['id']
    st = fake.install(clicks={'approve_' + pid})
    st.session_state['al_session'] = s
    st.session_state['al_language'] = 'en-IN'
    st.session_state['al_reviewer'] = 'Tester'
    render(st, 'review')
    out = s.state()['outcome']
    assert out['status'] == 'verified'

    # Every page renders in the scanned state with no errors
    st = fake.install()
    st.session_state['al_session'] = s
    for name in PAGES:
        render(st, name)
    assert not st.errors
    kinds = {k for k, *_ in st.rendered}
    assert 'download_button' in kinds and 'components.html' in kinds


@needs_axe
def test_page_text_is_escaped():
    from streamlit_ui import ui
    assert ui.badge('<script>', 'critical').count('<script>') == 0
    html = ui.diff_html([{'kind': 'add', 'text': '<img src=x onerror=alert(1)>'}])
    assert '<img' not in html and '&lt;img' in html


@pytest.mark.skipif(not HAS_STREAMLIT, reason='Streamlit is not installed')
def test_app_runs_under_streamlit_apptest():
    # Runs in a fresh interpreter state: remove the stand-in first.
    for name in [m for m in sys.modules if m == 'streamlit' or m.startswith('streamlit.') or m.startswith('streamlit_ui')]:
        del sys.modules[name]
    from streamlit.testing.v1 import AppTest
    at = AppTest.from_file(str(ROOT / 'app.py'), default_timeout=60).run()
    assert not at.exception, [e.value for e in at.exception]
