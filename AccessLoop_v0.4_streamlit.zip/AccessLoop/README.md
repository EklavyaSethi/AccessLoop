# AccessLoop · Reviewed accessibility repair

**Team OracleZero · AgentOps 2026 · Autonomous Workflow Automation · 24 October 2026**

A deliberately bounded, auditable developer tool that scans an owned static HTML page using Chromium + axe-core, generates safe source-preserving patch proposals for three supported rule families, asks for explicit developer approval, applies changes to a separate working copy, rescans, and rolls back regressions.

**This is a hackathon proof of concept, not a WCAG certification tool or production-hosted website repair service.**

> **New:** `streamlit run app.py` now opens a multi-page app (landing page plus a sidebar page for every operation, code in `streamlit_ui/`). A dependency-light local web UI (`python -m accessloop.web`) shares the same engine and is kept as a fallback. See `docs/HOW_IT_WORKS.md` for a plain-language explanation and `docs/ISSUE_CATALOG.md` for the full issue catalogue.

## Core demonstration

1. Select **Load seeded demo page**.
2. Select **Run accessibility scan**. Expect the seeded `html-has-lang`, `label`, and `button-name` findings to appear (additional axe findings are possible and are shown separately).
3. Open a diff. Select **Reject (no change)** and inspect the unchanged working-file hash in the audit trail.
4. Select **Approve and verify** on a proposal. It is written to the separate working copy **only after approval**, then rescanned.
5. Fix the remaining supported findings and inspect **verified** events, evidence JSON, and corrected HTML.
6. Load `examples/ambiguous_icon_button.html`: `button-name` should be reported without an invented fix; this is an intentional escalation.

## Setup (macOS)

You need **Python 3.11+**, **Node.js with npm**, and an internet connection during setup to install browser + packages.

```bash
cd AccessLoop_Hackathon_Starter
bash setup_mac.sh
source .venv/bin/activate
streamlit run app.py
```

Open the local Streamlit address printed in the terminal (normally http://localhost:8501).

### Manual setup (macOS / Linux)

```bash
python3 -m venv .venv
source .venv/bin/activate
python -m pip install -r requirements.txt
python -m playwright install chromium
npm install --no-audit --no-fund
python -m pytest -q
python -m accessloop.smoke
streamlit run app.py
```

**Do not skip `python -m accessloop.smoke`:** it verifies the complete scanner → approval → patch → rescan workflow with the actual axe library. `npm install` caches axe-core locally; no external CDN is used during a scan.

### Optional genuine LLM review

```bash
python -m pip install -r requirements-ai.txt
export GEMINI_API_KEY='your_key_here'
# optional: export GEMINI_MODEL='gemini-2.5-flash'
streamlit run app.py
```

Choose **Optional: AI triage → Request AI review** after generating proposals. AI recommends or escalates a restricted patch, and explains why. It **cannot** generate arbitrary executable patches, alter the file, bypass human approval, or decide whether the axe rescan passed. Without an API key, the UI explicitly identifies the deterministic fallback. Only use synthetic, non-sensitive source snippets with the remote API. Never commit `.env` or credentials.

## What is supported?

| Axe rule | Patch template | Evidence required |
|---|---|---|
| `html-has-lang` | Insert `lang` attribute on `<html>` | Reviewer explicitly selects language |
| `label` | Connect immediately adjacent visible `<label>` to a uniquely identified `<input>` | Label text already exists, and axe points to the unique input |
| `button-name` | Remove incorrect `aria-hidden="true"` from the button's only visible text span | The actual button text already exists and axe points to the unique button |

If evidence is ambiguous, AccessLoop returns **manual review**, not a guessed text label. Other axe findings are displayed but not auto-edited. The scanner counts violation *nodes* by rule; rules marked **incomplete** also require manual checks. No automated scanner covers all accessibility barriers.

## Technical structure

```
app.py                        # Streamlit entry point (sidebar navigation)
streamlit_ui/                 # Streamlit pages: home, load, scan, review, verify, manual, preview, reports, audit, coverage, how
accessloop/models.py          # typed findings / proposals / scan results
accessloop/scanner.py         # headless Chromium + locally-installed axe-core
accessloop/planner.py         # constrained, source-preserving patch generation
accessloop/ai_advisor.py      # optional, non-executing Gemini classification
accessloop/workflow.py        # workspace state, write controls, backups, event log
accessloop/verification.py    # target reduction and no-new-automated-issue gate
accessloop/smoke.py           # full browser integration test
examples/                     # seeded and ambiguous HTML examples
examples/samples/             # 5 acceptance pages: multi-fix, mixed, edge cases, clean control, unsafe input
accessloop/sample_suite.py    # real-browser acceptance runner + report
tests/                        # independent engine tests
```

## Quality gates

- No file write on a rejected patch or missing approval.
- The original HTML is preserved separately from `working.html`.
- Proposal ID and SHA-256 bind the patch to the precise source version.
- Patch is regenerated from an allowlisted template before writing.
- Every successful write is immediately rescanned; no improvement / increased violations / scan failure triggers rollback.
- Files are written through temporary files and `os.replace` for atomic replacement.
- A JSON audit log records event type, timestamp and working-file hashes.
- Unrecognized or under-specified findings are escalated, not fabricated.
- Static HTML under 200 KB only; scripts and inline event handlers are disallowed; external browser requests are blocked.

This does *not* yet include comprehensive concurrency control, filesystem isolation against maliciously crafted HTML, full HTML source maps, visual regression testing, secure multi-tenant deployment, or screen-reader user testing. Do not describe this proof of concept as enterprise production ready.

## Fast commands

```bash
python -m pytest -q                # unit tests (fake scanner)
python -m accessloop.smoke         # real axe + Chromium integration smoke test
python -m accessloop.sample_suite  # 8 real-browser acceptance cases over examples/samples -> sample_results/RESULTS.md
python -m accessloop.web           # fallback local web UI (http://127.0.0.1:8765), no extra install needed
python -m accessloop.catalog       # regenerate docs/ISSUE_CATALOG.md and data/issue_catalog.*
streamlit run app.py               # main multi-page Streamlit UI
```

See `docs/ARCHITECTURE.md`, `docs/DEMO_SCRIPT.md`, `docs/8_HOUR_PLAN.md`, and `docs/TEST_MATRIX.md` before the event.

## Hackathon rule check

Verify whether the event permits bringing prewritten starter code. If not, treat this package as a **pre-event rehearsal/reference** and implement according to the event's rules during the official build window.

## References

- [WebAIM Million 2026](https://webaim.org/projects/million/)
- [W3C WCAG 2.2](https://www.w3.org/TR/WCAG22/)
- [axe-core](https://github.com/dequelabs/axe-core)
- [Playwright for Python](https://playwright.dev/python/docs/intro)
- [Streamlit Session State](https://docs.streamlit.io/develop/concepts/architecture/session-state)
- [Gemini structured output](https://ai.google.dev/gemini-api/docs/structured-output)
