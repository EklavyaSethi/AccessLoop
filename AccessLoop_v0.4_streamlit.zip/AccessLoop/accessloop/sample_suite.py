"""Real-browser acceptance suite over examples/ + examples/samples/.

Runs every sample through the actual Workflow (Chromium + axe-core), checks the
expected agent behaviour (fix / abstain / refuse), and writes a report.

    python -m accessloop.sample_suite [--out sample_results]
"""
from __future__ import annotations
import argparse
import json
from dataclasses import dataclass, field
from pathlib import Path
from tempfile import TemporaryDirectory
from typing import Callable

from .planner import sha256
from .workflow import Workflow, WorkflowError

ROOT = Path(__file__).resolve().parent.parent
SUPPORTED = ('html-has-lang', 'label', 'button-name')


@dataclass
class CaseResult:
    name: str
    file: str
    purpose: str
    passed: bool = True
    checks: list[tuple[str, bool]] = field(default_factory=list)
    baseline: dict = field(default_factory=dict)
    final: dict = field(default_factory=dict)
    applied: list[dict] = field(default_factory=list)
    manual_queue: list[str] = field(default_factory=list)
    note: str = ''

    def check(self, label: str, ok: bool) -> None:
        self.checks.append((label, bool(ok)))
        self.passed = self.passed and bool(ok)


def _approve_all(engine: Workflow, result: CaseResult, language: str = 'en', limit: int = 12) -> None:
    for _ in range(limit):
        if not engine.proposals:
            return
        p = engine.proposals[0]
        out = engine.apply(p.proposal_id, approved=True, language=language)
        result.applied.append({'rule': p.rule_id, 'selector': p.selector, 'status': out.status,
                               'before': p.before, 'after': p.after, 'detail': out.detail})
    result.check('loop terminates within limit', not engine.proposals)


def _finish(engine: Workflow, result: CaseResult, out_dir: Path | None, stem: str) -> None:
    result.final = dict(engine.current_scan.counts())
    result.manual_queue = [f'{f.rule_id} {f.selector}' for f in engine.current_scan.findings]
    if out_dir:
        (out_dir / f'{stem}.repaired.html').write_text(engine.current_html, encoding='utf-8')
        (out_dir / f'{stem}.evidence.json').write_text(engine.report_json(), encoding='utf-8')


def run_case(name: str, file: str, purpose: str, body: Callable[[Workflow, str, CaseResult], None],
             out_dir: Path | None) -> CaseResult:
    path = ROOT / file
    source = path.read_text(encoding='utf-8')
    result = CaseResult(name, file, purpose)
    with TemporaryDirectory() as tmp:
        engine = Workflow(Path(tmp))
        try:
            body(engine, source, result)
            if engine.loaded and engine.current_scan is not None:
                result.check('original.html never modified',
                             sha256((Path(tmp) / 'original.html').read_text(encoding='utf-8')) == sha256(source))
                _finish(engine, result, out_dir, path.stem)
        except Exception as error:  # an unexpected crash is a failed case, not a suite crash
            result.check(f'no unexpected exception ({type(error).__name__}: {error})', False)
    return result


# ---------- case bodies ----------

def seeded_demo(engine, source, r):
    engine.load(source)
    r.baseline = dict(engine.scan().counts())
    r.check('3 seeded rules detected', set(SUPPORTED) <= r.baseline.keys())
    _approve_all(engine, r)
    r.check('every applied patch verified', r.applied and all(a['status'] == 'verified' for a in r.applied))
    r.check('seeded rules cleared', not any(engine.current_scan.counts()[k] for k in SUPPORTED))


def library_signup(engine, source, r):
    engine.load(source)
    r.baseline = dict(engine.scan().counts())
    r.check('html-has-lang=1, label=3, button-name=1 detected',
            r.baseline.get('html-has-lang') == 1 and r.baseline.get('label') == 3 and r.baseline.get('button-name') == 1)
    r.check('5 proposals generated', len(engine.proposals) == 5)
    # Human rejects first: must not write.
    h = sha256(engine.current_html)
    engine.reject(engine.proposals[0].proposal_id)
    r.check('reject leaves working file byte-identical', sha256(engine.current_html) == h)
    # approved=False is treated as rejection.
    engine.apply(engine.proposals[0].proposal_id, approved=False)
    r.check('approved=False leaves working file byte-identical', sha256(engine.current_html) == h)
    # Stale proposal must be blocked after another edit lands.
    stale = engine.proposals[-1]
    _approve_all(engine, r)
    try:
        engine.apply(stale.proposal_id, approved=True)
        r.check('stale proposal blocked', False)
    except WorkflowError:
        r.check('stale proposal blocked', True)
    r.check('5 patches applied, all verified', len(r.applied) == 5 and all(a['status'] == 'verified' for a in r.applied))
    r.check('all supported rules cleared', not any(engine.current_scan.counts()[k] for k in SUPPORTED))
    r.check('total violations reach 0', len(engine.current_scan.findings) == 0)


def library_bad_language(engine, source, r):
    engine.load(source)
    r.baseline = dict(engine.scan(language='english').counts())
    r.check('invalid language code -> no html-has-lang proposal',
            not any(p.rule_id == 'html-has-lang' for p in engine.proposals))
    r.check('other proposals still offered', len(engine.proposals) == 4)
    r.note = 'Reviewer language "english" is not a BCP-47 code; agent abstains for that rule only.'


def event_feedback(engine, source, r):
    engine.load(source)
    r.baseline = dict(engine.scan().counts())
    r.check('label detected', r.baseline.get('label', 0) >= 1)
    r.check('unsupported rules detected (image-alt, link-name, select-name)',
            {'image-alt', 'link-name', 'select-name'} <= r.baseline.keys())
    r.check('exactly 1 proposal (the label)', [p.rule_id for p in engine.proposals] == ['label'])
    _approve_all(engine, r)
    final = engine.current_scan.counts()
    r.check('label patch verified', r.applied and r.applied[0]['status'] == 'verified')
    r.check('unsupported issues left for manual review, not edited',
            all(final[k] == r.baseline[k] for k in ('image-alt', 'link-name', 'select-name')))


def tricky(engine, source, r):
    engine.load(source)
    r.baseline = dict(engine.scan().counts())
    r.check('label and button-name findings detected',
            r.baseline.get('label', 0) >= 3 and r.baseline.get('button-name', 0) >= 2)
    r.check('ZERO proposals (agent abstains on every ambiguous pattern)', engine.proposals == ())
    r.check('working file untouched', engine.current_html == source)


def accessible(engine, source, r):
    engine.load(source)
    r.baseline = dict(engine.scan().counts())
    r.check('zero violations on clean page', not r.baseline)
    r.check('zero proposals', engine.proposals == ())


def unsafe(engine, source, r):
    try:
        engine.load(source)
        r.check('script/onclick page refused before scan', False)
    except WorkflowError as error:
        r.check('script/onclick page refused before scan', True)
        r.note = f'Refused: {error}'


def ambiguous_icon(engine, source, r):
    engine.load(source)
    r.baseline = dict(engine.scan().counts())
    r.check('button-name detected', r.baseline.get('button-name') == 1)
    r.check('no invented label (0 proposals)', engine.proposals == ())


CASES = [
    ('Seeded demo (starter)', 'examples/student_registration.html', 'Baseline smoke: 3 seeded rules fixed end-to-end', seeded_demo),
    ('Ambiguous icon (starter)', 'examples/ambiguous_icon_button.html', 'Icon-only button must escalate', ambiguous_icon),
    ('S1 Library sign-up', 'examples/samples/01_library_signup.html', 'Multiple instances + reject / no-approval / stale guards', library_signup),
    ('S1b Invalid language', 'examples/samples/01_library_signup.html', 'Bad reviewer language input', library_bad_language),
    ('S2 Event feedback', 'examples/samples/02_event_feedback.html', 'Mixed: 1 fixable, 3 unsupported -> manual queue', event_feedback),
    ('S3 Tricky edge cases', 'examples/samples/03_tricky_edge_cases.html', 'Six near-miss patterns; agent must abstain', tricky),
    ('S4 Accessible contact', 'examples/samples/04_accessible_contact.html', 'Clean control page; no false positives / edits', accessible),
    ('S5 Unsafe newsletter', 'examples/samples/05_unsafe_newsletter.html', 'Script + inline handler refused at input', unsafe),
]


def to_markdown(results: list[CaseResult]) -> str:
    lines = ['# AccessLoop sample-suite results', '',
             f'**{sum(r.passed for r in results)}/{len(results)} cases passed** '
             '(real Chromium + axe-core, no fake scanner)', '']
    for r in results:
        lines += [f'## {"PASS" if r.passed else "FAIL"} - {r.name}', f'`{r.file}` - {r.purpose}', '']
        if r.baseline or r.final:
            lines.append(f'- Baseline counts: `{r.baseline}`  ->  Final counts: `{r.final}`')
        for a in r.applied:
            lines.append(f'- {a["status"]}: **{a["rule"]}** `{a["selector"]}`  `{a["before"]}` -> `{a["after"]}`')
        if r.manual_queue:
            lines.append(f'- Manual-review queue: {", ".join(f"`{m}`" for m in r.manual_queue)}')
        if r.note:
            lines.append(f'- Note: {r.note}')
        for label, ok in r.checks:
            lines.append(f'  - [{"x" if ok else " "}] {label}')
        lines.append('')
    return '\n'.join(lines)


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument('--out', default='sample_results')
    args = ap.parse_args()
    out = Path(args.out)
    out.mkdir(parents=True, exist_ok=True)
    results = [run_case(n, f, p, b, out) for n, f, p, b in CASES]
    md = to_markdown(results)
    (out / 'RESULTS.md').write_text(md, encoding='utf-8')
    (out / 'results.json').write_text(json.dumps([r.__dict__ for r in results], indent=2, default=str), encoding='utf-8')
    print(md)
    return 0 if all(r.passed for r in results) else 1


if __name__ == '__main__':
    raise SystemExit(main())
