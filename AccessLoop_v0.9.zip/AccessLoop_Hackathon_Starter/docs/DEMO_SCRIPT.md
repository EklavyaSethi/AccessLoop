# 3-minute live demo (v0.9)

Before you start: `streamlit run app.py`, sign in, interface language English, browser zoom 100%.

## 0:00–0:20 — Pain point

"Scanners tell developers what is wrong. Someone still has to find the code, choose a fix, edit it and test again.
AccessLoop closes that loop, and nothing changes without a person's approval."

## 0:20–0:45 — Load and scan

**Load page** → sample *02 SIP signup* → **Scan**. Real Chromium + axe-core, scripts never run, network blocked.
Point at the metrics: violations, fixes ready, needs a human check.

## 0:45–1:25 — Review, preview, approve

Open a form-label fix: show the exact diff and **Preview what a screen reader will hear** (before: a field with no name; after: the field announced
with its label). **Reject** one fix first: audit log shows no write. Then **Approve and verify**: re-scan,
count falls, marked verified. Use **Approve all** for a batch of identical fixes.

## 1:25–1:50 — It refuses to guess, and it rolls back

Icon-only button: AccessLoop asks for the words instead of inventing them. Mention: if a fix makes anything else
worse, it is rolled back automatically, byte for byte.

## 1:50–2:20 — Evidence

**Verify results**: before/after by severity. **Reports**: git patch, signed evidence, ACR report, Jira CSV.
**Audit trail**: hash chain verified, decisions signed by the signed-in reviewer.

## 2:20–2:45 — Scale

**Site scan**: upload a .zip; identical problems grouped by shared template. Mention template mapping (Jinja etc.) and
the CLI/CI with SARIF.

## 2:45–3:00 — Proof and limits

"Validated on 464 third-party pages: 97% of approved decisions verified, MDN 286 → 13 violations, zero pages made worse.
It does not certify WCAG conformance; the manual checklist covers what tools cannot."

## Judge Q&A

- **Why agentic?** It plans an edit from evidence, waits for approval, acts with a bounded tool, observes an
  independent re-scan, then commits, rolls back or escalates.
- **Why not an LLM rewriting pages?** A plausible wrong label is worse than none. Templates are deterministic; AI is
  optional, advisory, consented and redacted.
- **How many issue types?** 83 axe rules fixed live, 6 guided, all 55 WCAG 2.2 A/AA criteria in the manual checklist.
- **Frameworks?** Static HTML, rendered pages, and server-side templates today; React/Angular/Vue sources on the roadmap.
- **Enterprise?** Local accounts with signed decisions, four-eyes, per-user workspaces, SBOM and dependency audit in CI.
  SSO is designed for, not yet built.
