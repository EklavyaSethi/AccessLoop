"""Runs the actual axe-core browser engine, with zero CDN dependency at runtime."""
from __future__ import annotations
import os
from pathlib import Path
from playwright.sync_api import sync_playwright
from .htmlsource import Doc, instrument
from .models import ScanResult

ROOT = Path(__file__).resolve().parent.parent
AXE_PATH = Path(os.environ.get('ACCESSLOOP_AXE_PATH', str(ROOT / 'node_modules/axe-core/axe.min.js')))
TAGS = ['wcag2a', 'wcag2aa', 'wcag21a', 'wcag21aa', 'wcag22a', 'wcag22aa']
BEST_PRACTICE_TAGS = TAGS + ['best-practice']


class ScanError(RuntimeError):
    pass


def _block(route) -> None:
    """Nothing is fetched. A navigation (meta refresh, frame src) gets "204 No Content", which browsers treat as
    'stay on this page', so the scanned document is never replaced; every other request is aborted."""
    try:
        if route.request.is_navigation_request():
            route.fulfill(status=204, body='')
        else:
            route.abort()
    except Exception:  # noqa: BLE001 - the request may already be gone
        pass


def scan_html(html: str, best_practice: bool = False) -> ScanResult:
    """Scan with the WCAG A/AA rules; best_practice=True also runs axe's best-practice rules."""
    if not AXE_PATH.is_file():
        raise ScanError('axe-core not installed. Run `npm install` in the project directory first.')
    try:
        with sync_playwright() as playwright:
            launch_args = {'headless': True}
            # Optional override for environments with a system Chromium installation.
            if os.getenv('ACCESSLOOP_CHROMIUM_EXECUTABLE'):
                launch_args['executable_path'] = os.environ['ACCESSLOOP_CHROMIUM_EXECUTABLE']
            browser = playwright.chromium.launch(**launch_args)
            try:
                context = browser.new_context(service_workers='block')
                # Demo accepts trusted static pages. Block all external resource requests.
                context.route('**/*', _block)
                page = context.new_page()
                page.set_default_timeout(10000)
                # Tag every start tag with data-al-uid so each finding maps to an exact source element.
                page.set_content(instrument(Doc(html)), wait_until='domcontentloaded', timeout=15000)
                page.add_script_tag(path=str(AXE_PATH))
                data = page.evaluate('''async (tags) => {
                    const res = await window.axe.run(document, {
                        runOnly: { type: 'tag', values: tags },
                        iframes: false,   // frame contents are never loaded (all requests are blocked)
                        rules: { 'frame-tested': { enabled: false }, 'frame-focusable-content': { enabled: false } },
                        resultTypes: ['violations', 'incomplete', 'passes']
                    });
                    for (const v of res.violations.concat(res.incomplete)) {
                        for (const n of v.nodes) {
                            let uid = null;
                            try {
                                const sel = Array.isArray(n.target) ? n.target[0] : null;
                                const el = typeof sel === 'string' ? document.querySelector(sel) : null;
                                if (el) uid = el.getAttribute('data-al-uid');
                            } catch (e) { uid = null; }
                            n.uid = uid;
                        }
                    }
                    return res;
                }''', BEST_PRACTICE_TAGS if best_practice else TAGS)
                return ScanResult.from_axe(data)
            finally:
                browser.close()
    except ScanError:
        raise
    except Exception as error:
        raise ScanError(f'Browser scan failed: {error}') from error
