"""AccessLoop local web interface. Standard library only; bound to 127.0.0.1.

    python -m accessloop.web            # opens http://127.0.0.1:8765

The engine (workflow, planner, scanner, verifier) is unchanged. This module adds a JSON API,
a single in-memory working session, and a richer evidence log (who approved what, when).
"""
from __future__ import annotations
import argparse
import difflib
import json
import re
import threading
import uuid
import webbrowser
from collections import Counter
from datetime import datetime, timezone
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from urllib.parse import urlparse

from .. import __version__
from .. import catalog as catalog_mod
from ..ai_advisor import AIUnavailable, review_proposals
from ..planner import sha256
from ..workflow import Workflow, WorkflowError, read_source
from . import report as report_mod

PKG = Path(__file__).resolve().parent
STATIC = PKG / 'static'
ROOT = PKG.parent.parent
MAX_BODY = 1_000_000
IMPACTS = ('critical', 'serious', 'moderate', 'minor')
LANGUAGES = [
    ('en', 'English'), ('en-IN', 'English (India)'), ('hi', 'Hindi'), ('bn', 'Bengali'), ('ta', 'Tamil'),
    ('te', 'Telugu'), ('mr', 'Marathi'), ('gu', 'Gujarati'), ('kn', 'Kannada'), ('ml', 'Malayalam'),
    ('pa', 'Punjabi'), ('ur', 'Urdu'), ('fr', 'French'), ('es', 'Spanish'), ('de', 'German'),
]
LANGUAGE_CODES = {code for code, _ in LANGUAGES}
CONTENT_TYPES = {'.html': 'text/html; charset=utf-8', '.css': 'text/css; charset=utf-8',
                 '.js': 'text/javascript; charset=utf-8', '.svg': 'image/svg+xml'}
APP_CSP = ("default-src 'self'; img-src 'self' data:; style-src 'self'; script-src 'self'; frame-src 'self'; "
           "base-uri 'none'; form-action 'none'; frame-ancestors 'self'; object-src 'none'")
PREVIEW_CSP = "default-src 'none'; style-src 'unsafe-inline'; img-src data:; sandbox"


class ApiError(Exception):
    def __init__(self, message: str, status: int = 400):
        super().__init__(message)
        self.status = status


def _now() -> str:
    return datetime.now(timezone.utc).isoformat(timespec='seconds')


def _clean_name(value: object, limit: int = 80) -> str:
    text = re.sub(r'[\x00-\x1f\x7f]', '', str(value or '')).strip()
    return text[:limit]


def diff_lines(before: str, after: str) -> list[dict]:
    raw = list(difflib.unified_diff(before.splitlines(), after.splitlines(), fromfile='before', tofile='proposed', n=2, lineterm=''))
    out = []
    for line in raw:
        if line.startswith(('---', '+++', '@@')):
            out.append({'kind': 'meta', 'text': line})
        elif line.startswith('+'):
            out.append({'kind': 'add', 'text': line[1:]})
        elif line.startswith('-'):
            out.append({'kind': 'del', 'text': line[1:]})
        else:
            out.append({'kind': 'ctx', 'text': line[1:] if line.startswith(' ') else line})
    if not any(x['kind'] in ('add', 'del') for x in out):
        out = [{'kind': 'del', 'text': before}, {'kind': 'add', 'text': after}]
    return out


class Session:
    """One working session: the engine plus the extra evidence the UI records."""

    def __init__(self, root: Path = ROOT):
        self.lock = threading.RLock()
        self.root = root
        self.catalog = catalog_mod.build()
        self.rules = {r['rule_id']: r for r in self.catalog['rules']}
        self.engine: Workflow | None = None
        self._clear()

    def _clear(self) -> None:
        self.source_name = ''
        self.language = 'en'
        self.reviewer = ''
        self.outcome: dict | None = None
        self.fix_log: list[dict] = []
        self.ai_review: dict = {}

    # ---- samples ------------------------------------------------------------------------------
    def samples(self) -> list[dict]:
        out = []
        for path in sorted((self.root / 'examples' / 'samples').rglob('*.html')):
            rel = path.relative_to(self.root).as_posix()
            match = re.search(r'<title>(.*?)</title>', path.read_text(encoding='utf-8', errors='replace'), re.I | re.S)
            out.append({'id': rel, 'label': (match.group(1).strip() if match else path.stem)})
        return out

    def _sample_text(self, sample_id: str) -> tuple[str, str]:
        allowed = {s['id'] for s in self.samples()}
        if sample_id not in allowed:
            raise ApiError('Unknown sample page.')
        return (self.root / sample_id).read_text(encoding='utf-8'), Path(sample_id).name

    # ---- actions ------------------------------------------------------------------------------
    def load(self, html: str | None, name: str, sample: str | None = None) -> None:
        with self.lock:
            if sample:
                html, name = self._sample_text(sample)
            if not isinstance(html, str):
                raise ApiError('No HTML provided.')
            engine = Workflow(self.root / '.accessloop_workspaces' / uuid.uuid4().hex)
            engine.load(html)  # raises WorkflowError for unsafe or oversized input; existing session is kept
            reviewer = self.reviewer
            self.engine = engine
            self._clear()
            self.reviewer = reviewer
            self.source_name = _clean_name(name, 120) or 'uploaded.html'

    def _need_loaded(self) -> Workflow:
        if self.engine is None or not self.engine.loaded:
            raise ApiError('Load a page first.', 409)
        return self.engine

    def _need_scanned(self) -> Workflow:
        engine = self._need_loaded()
        if engine.current_scan is None:
            raise ApiError('Run a scan first.', 409)
        return engine

    @staticmethod
    def _language(value: object) -> str:
        if value not in LANGUAGE_CODES:
            raise ApiError('Choose a language from the list.')
        return str(value)

    def scan(self, language: object, best_practice: object = False) -> None:
        with self.lock:
            engine = self._need_loaded()
            self.language = self._language(language)
            engine.scan(language=self.language, best_practice=bool(best_practice is True or best_practice == 'true'))
            self.outcome = None
            self.ai_review = {}

    def _proposal(self, engine: Workflow, proposal_id: object):
        match = next((p for p in engine.proposals if p.proposal_id == proposal_id), None)
        if match is None:
            raise ApiError('Unknown or expired proposal. Run the scan again.', 409)
        return match

    def _log(self, proposal, decision: str, status: str, detail: str, counts: tuple[int, int]) -> None:
        info = self.rules.get(proposal.rule_id, {})
        self.fix_log.append({
            'time_utc': _now(), 'proposal_id': proposal.proposal_id, 'rule': proposal.rule_id,
            'selector': proposal.selector, 'wcag': info.get('wcag', []), 'level': info.get('level', ''),
            'before': proposal.before, 'after': proposal.after, 'evidence': proposal.evidence,
            'explanation': proposal.explanation, 'decision': decision, 'status': status, 'detail': detail,
            'reviewer': self.reviewer, 'findings_before': counts[0], 'findings_after': counts[1],
        })

    def approve(self, proposal_id: object, language: object, reviewer: object, values: object = None) -> None:
        with self.lock:
            engine = self._need_scanned()
            proposal = self._proposal(engine, proposal_id)
            self.reviewer = _clean_name(reviewer)
            self.language = self._language(language)
            if values is not None and not isinstance(values, dict):
                raise ApiError('Typed values must be an object.')
            clean = {str(k)[:40]: (v if isinstance(v, bool) else str(v)[:300]) for k, v in (values or {}).items()} or None
            out = engine.apply(proposal.proposal_id, approved=True, language=self.language, values=clean,
                               reviewer=self.reviewer or None)
            applied = engine.last_candidate if out.status in ('verified', 'rolled_back') else None
            logged = proposal
            if applied is not None and applied.proposal_id == proposal.proposal_id:
                logged = applied      # records the exact text that was written, including reviewer-typed text
            self._log(logged, 'approved', out.status, out.detail, (out.before_count, out.after_count))
            self.outcome = {**out.to_dict(), 'rule': proposal.rule_id, 'selector': proposal.selector}
            self.ai_review = {}

    def reject(self, proposal_id: object, reviewer: object) -> None:
        with self.lock:
            engine = self._need_scanned()
            proposal = self._proposal(engine, proposal_id)
            self.reviewer = _clean_name(reviewer)
            out = engine.reject(proposal.proposal_id, self.reviewer or None)
            self._log(proposal, 'rejected', 'rejected', out.detail, (out.before_count, out.after_count))
            self.outcome = {**out.to_dict(), 'rule': proposal.rule_id, 'selector': proposal.selector}

    def reset(self) -> None:
        with self.lock:
            engine = self._need_loaded()
            engine.reset()
            reviewer, name, log = self.reviewer, self.source_name, self.fix_log
            self._clear()
            self.reviewer, self.source_name = reviewer, name
            # Decisions stay on record; the reset itself is recorded too (and in the hash-chained audit log).
            self.fix_log = log + [{'time_utc': _now(), 'proposal_id': '', 'rule': '(reset)', 'selector': '', 'wcag': [],
                                   'level': '', 'before': '', 'after': '', 'evidence': '', 'explanation': '',
                                   'decision': 'reset', 'status': 'reset',
                                   'detail': 'Working copy restored to the original; earlier fixes undone.',
                                   'reviewer': self.reviewer, 'findings_before': None, 'findings_after': None}]

    def ai(self) -> dict:
        with self.lock:
            engine = self._need_scanned()
            try:
                self.ai_review = review_proposals(engine.proposals)
            except AIUnavailable as error:
                return {'available': False, 'message': f'AI review unavailable; the deterministic workflow is unaffected. {error}'}
            return {'available': True, 'message': 'AI review completed. Its advice is non-binding.', 'advice': self.ai_review}

    # ---- views --------------------------------------------------------------------------------
    def state(self) -> dict:
        with self.lock:
            base = {'languages': [{'code': c, 'name': n} for c, n in LANGUAGES], 'version': __version__,
                    'reviewer': self.reviewer, 'loaded': False, 'scanned': False}
            engine = self.engine
            if engine is None or not engine.loaded:
                return base
            original = read_source(engine.workspace / 'original.html')
            current = engine.current_html
            base.update({'loaded': True, 'source_name': self.source_name, 'language': self.language,
                         'sha_original': sha256(original), 'sha_current': sha256(current),
                         'changed': original != current, 'outcome': self.outcome,
                         'events': list(reversed(engine.events)), 'fix_log': list(self.fix_log),
                         'audit': engine.audit_status()})
            scan = engine.current_scan
            if scan is None:
                base['source_preview'] = current[:6000]
                return base
            impact_of = {(f.rule_id, f.selector): f.impact for f in scan.items}
            proposals = []
            for p in engine.proposals:
                info = self.rules.get(p.rule_id, {})
                proposals.append({
                    'id': p.proposal_id, 'rule': p.rule_id, 'selector': p.selector,
                    'impact': impact_of.get((p.rule_id, p.selector), 'unknown'), 'title': info.get('title', p.rule_id),
                    'wcag': info.get('wcag', []), 'level': info.get('level', ''), 'explanation': p.explanation,
                    'evidence': p.evidence, 'diff': diff_lines(p.before, p.after), 'ai': self.ai_review.get(p.proposal_id),
                    'mode': p.mode, 'needs_input': p.needs_input, 'fields': list(p.fields), 'risk': p.risk,
                    'line': p.line, 'kind': scan.items[p.finding_index].kind if 0 <= p.finding_index < len(scan.items) else 'violation',
                })
            eligible = {(p.rule_id, p.selector) for p in engine.proposals}
            unresolved = []
            for f in scan.items:
                if (f.rule_id, f.selector) in eligible:
                    continue
                info = self.rules.get(f.rule_id, {})
                unresolved.append({
                    'rule': f.rule_id, 'selector': f.selector, 'impact': f.impact, 'help': f.help,
                    'description': f.description[:600], 'wcag': info.get('wcag', []), 'level': info.get('level', ''),
                    'handling': info.get('handling', 'unclassified'),
                    'handling_label': 'Needs a human check (axe could not decide)' if f.kind == 'review'
                                      else catalog_mod.HANDLING.get(info.get('handling', ''), 'Unclassified'),
                    'note': info.get('note', ''), 'help_url': info.get('help_url', ''), 'kind': f.kind,
                })
            before = engine.before or scan
            events = engine.run_events
            base.update({
                'scanned': True, 'proposals': proposals, 'unresolved': unresolved,
                'metrics': {
                    'baseline': len(before.findings), 'current': len(scan.findings), 'eligible': len(proposals),
                    'manual': len(unresolved), 'incomplete': scan.incomplete, 'passed_rules': scan.passed_rules,
                    'needs_review': len(scan.reviews), 'best_practice': engine.best_practice,
                    'verified': sum(e['event'] == 'verified' for e in events),
                    'rejected': sum(e['event'] == 'rejected' for e in events),
                    'rolled_back': sum(e['event'] == 'rolled_back' for e in events),
                },
                'severity': {
                    'baseline': self._by_impact(before.findings), 'current': self._by_impact(scan.findings),
                },
                'rule_counts': {'baseline': dict(before.counts()), 'current': dict(scan.counts())},
            })
            return base

    @staticmethod
    def _by_impact(findings) -> dict:
        counts = Counter(f.impact for f in findings)
        out = {k: counts.get(k, 0) for k in IMPACTS}
        if counts.get('unknown'):
            out['unknown'] = counts['unknown']
        return out

    def report_payload(self) -> dict:
        with self.lock:
            self._need_scanned()
            state = self.state()
            return {
                **state, 'generated_utc': _now(), 'tool_version': __version__,
                'axe_version': self.catalog['axe_version'], 'coverage': self.catalog['summary'],
                'manual_only_criteria': [{'criterion': c['criterion'], 'name': c['name'], 'level': c['level']}
                                         for c in self.catalog['criteria'] if not c['axe_testable']],
            }

    def report_json(self) -> str:
        with self.lock:
            engine = self._need_scanned()
            doc = json.loads(engine.report_json())
            doc.update({'source_name': self.source_name, 'generated_utc': _now(), 'tool_version': __version__,
                        'axe_version': self.catalog['axe_version'], 'reviewer_recorded_as_typed': self.reviewer,
                        'language': self.language, 'fixes_and_decisions': self.fix_log,
                        'coverage': self.catalog['summary']})
            return json.dumps(doc, indent=2, ensure_ascii=False)

    def file(self, which: str) -> str:
        with self.lock:
            engine = self._need_loaded()
            return read_source(engine.workspace / ('original.html' if which == 'original' else 'working.html'))


class Handler(BaseHTTPRequestHandler):
    protocol_version = 'HTTP/1.1'
    server_version = 'AccessLoop'

    def log_message(self, fmt, *args):  # keep the terminal quiet
        pass

    # ---- plumbing -----------------------------------------------------------------------------
    @property
    def session(self) -> Session:
        return self.server.session  # type: ignore[attr-defined]

    def _send(self, status: int, body: bytes, content_type: str, csp: str | None = APP_CSP, extra: dict | None = None):
        self.send_response(status)
        self.send_header('Content-Type', content_type)
        self.send_header('Content-Length', str(len(body)))
        self.send_header('Cache-Control', 'no-store')
        self.send_header('X-Content-Type-Options', 'nosniff')
        self.send_header('Referrer-Policy', 'no-referrer')
        self.send_header('X-Frame-Options', 'SAMEORIGIN')
        if csp:
            self.send_header('Content-Security-Policy', csp)
        for key, value in (extra or {}).items():
            self.send_header(key, value)
        self.end_headers()
        self.wfile.write(body)

    def _json(self, payload: dict, status: int = 200):
        self._send(status, json.dumps(payload, ensure_ascii=False).encode('utf-8'), 'application/json; charset=utf-8')

    def _text(self, text: str, content_type: str, filename: str | None = None, csp: str | None = APP_CSP):
        extra = {'Content-Disposition': f'attachment; filename="{filename}"'} if filename else None
        self._send(200, text.encode('utf-8'), content_type, csp, extra)

    def _guard(self) -> None:
        host = (self.headers.get('Host') or '').lower()
        if host not in self.server.allowed_hosts:  # type: ignore[attr-defined]
            raise ApiError('Host not allowed.', 403)

    def _body(self) -> dict:
        if (self.headers.get('Content-Type') or '').split(';')[0].strip().lower() != 'application/json':
            raise ApiError('Content-Type must be application/json.', 415)
        origin = self.headers.get('Origin')
        if origin and origin.lower() != f'http://{self.headers.get("Host", "").lower()}':
            raise ApiError('Cross-origin request blocked.', 403)
        try:
            length = int(self.headers.get('Content-Length') or 0)
        except ValueError:
            raise ApiError('Bad Content-Length.')
        if length > MAX_BODY:
            raise ApiError('Request too large.', 413)
        try:
            data = json.loads(self.rfile.read(length) or b'{}')
        except json.JSONDecodeError:
            raise ApiError('Body is not valid JSON.')
        if not isinstance(data, dict):
            raise ApiError('Body must be a JSON object.')
        return data

    def _fail(self, error: Exception):
        if isinstance(error, ApiError):
            self._json({'error': str(error)}, error.status)
        elif isinstance(error, WorkflowError):
            self._json({'error': str(error)}, 400)
        else:
            self._json({'error': f'{type(error).__name__}: {error}'}, 500)

    # ---- routes -------------------------------------------------------------------------------
    def do_GET(self):
        try:
            self._guard()
            path = urlparse(self.path).path
            s = self.session
            if path == '/':
                return self._send(200, (STATIC / 'index.html').read_bytes(), CONTENT_TYPES['.html'])
            if path.startswith('/static/'):
                name = path[len('/static/'):]
                file = STATIC / name
                if '/' in name or '\\' in name or not file.is_file() or file.suffix not in CONTENT_TYPES:
                    raise ApiError('Not found.', 404)
                return self._send(200, file.read_bytes(), CONTENT_TYPES[file.suffix])
            if path == '/healthz':
                return self._json({'ok': True})
            if path == '/api/state':
                return self._json(s.state())
            if path == '/api/samples':
                return self._json({'samples': s.samples()})
            if path == '/api/catalog':
                return self._json(s.catalog)
            if path == '/api/catalog.csv':
                return self._text(catalog_mod.to_csv(s.catalog), 'text/csv; charset=utf-8', 'accessloop_issue_catalog.csv')
            if path == '/api/catalog.md':
                return self._text(catalog_mod.to_markdown(s.catalog), 'text/markdown; charset=utf-8', 'accessloop_issue_catalog.md')
            if path == '/api/report.html':
                return self._text(report_mod.build_html(s.report_payload()), CONTENT_TYPES['.html'], None,
                                  "default-src 'none'; style-src 'unsafe-inline'; img-src data:")
            if path == '/api/report.json':
                return self._text(s.report_json(), 'application/json; charset=utf-8', 'accessloop_evidence.json')
            if path in ('/api/working.html', '/api/original.html'):
                which = 'original' if 'original' in path else 'working'
                name = 'accessloop_original.html' if which == 'original' else 'accessloop_repaired.html'
                return self._text(s.file(which), CONTENT_TYPES['.html'], name, PREVIEW_CSP)
            if path in ('/preview/original.html', '/preview/working.html'):
                which = 'original' if 'original' in path else 'working'
                return self._text(s.file(which), CONTENT_TYPES['.html'], None, PREVIEW_CSP)
            raise ApiError('Not found.', 404)
        except Exception as error:  # noqa: BLE001 - every failure becomes a JSON error
            self._fail(error)

    def do_POST(self):
        try:
            self._guard()
            path = urlparse(self.path).path
            data = self._body()
            s = self.session
            if path == '/api/load':
                s.load(data.get('html'), _clean_name(data.get('name'), 120), data.get('sample'))
            elif path == '/api/scan':
                s.scan(data.get('language', 'en'), data.get('best_practice', False))
            elif path == '/api/approve':
                s.approve(data.get('id'), data.get('language', 'en'), data.get('reviewer'), data.get('values'))
            elif path == '/api/reject':
                s.reject(data.get('id'), data.get('reviewer'))
            elif path == '/api/reset':
                s.reset()
            elif path == '/api/ai-review':
                return self._json({**s.ai(), 'state': s.state()})
            else:
                raise ApiError('Not found.', 404)
            return self._json(s.state())
        except Exception as error:  # noqa: BLE001
            self._fail(error)


def make_server(port: int = 8765, root: Path = ROOT) -> ThreadingHTTPServer:
    server = ThreadingHTTPServer(('127.0.0.1', port), Handler)
    server.daemon_threads = True
    actual = server.server_address[1]
    server.allowed_hosts = {f'127.0.0.1:{actual}', f'localhost:{actual}'}  # type: ignore[attr-defined]
    server.session = Session(root)  # type: ignore[attr-defined]
    return server


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description='AccessLoop local web interface')
    parser.add_argument('--port', type=int, default=8765)
    parser.add_argument('--no-browser', action='store_true')
    args = parser.parse_args(argv)
    server = None
    for port in ([args.port] if args.port == 0 else range(args.port, args.port + 10)):
        try:
            server = make_server(port)
            break
        except OSError:
            continue
    if server is None:
        print(f'Could not bind a port starting at {args.port}.')
        return 1
    url = f'http://127.0.0.1:{server.server_address[1]}/'
    print(f'AccessLoop is running at {url}  (local only; press Ctrl+C to stop)')
    if not args.no_browser:
        webbrowser.open(url)
    try:
        server.serve_forever()
    except KeyboardInterrupt:
        print('\nStopped.')
    finally:
        server.server_close()
    return 0
