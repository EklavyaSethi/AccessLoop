"""Runs the actual axe-core browser engine, with zero CDN dependency at runtime."""
from __future__ import annotations
import os
from pathlib import Path
from playwright.sync_api import sync_playwright
import mimetypes
from .htmlsource import Doc, scan_copy
from .models import ScanResult

ROOT = Path(__file__).resolve().parent.parent
AXE_PATH = Path(os.environ.get('ACCESSLOOP_AXE_PATH', str(ROOT / 'node_modules/axe-core/axe.min.js')))
TAGS = ['wcag2a', 'wcag2aa', 'wcag21a', 'wcag21aa', 'wcag22a', 'wcag22aa']
BEST_PRACTICE_TAGS = TAGS + ['best-practice']


class ScanError(RuntimeError):
    pass


ASSET_ORIGIN = 'http://accessloop.local/'
ASSET_TYPES = {'.css', '.png', '.jpg', '.jpeg', '.gif', '.webp', '.svg', '.ico', '.woff', '.woff2', '.ttf', '.otf'}
MAX_ASSET_BYTES = 5 * 1024 * 1024


def _local_asset(url: str, assets_dir: Path | None) -> Path | None:
    """Map http://accessloop.local/<path> to a file inside assets_dir (style sheets, images, fonts only)."""
    if assets_dir is None or not url.startswith(ASSET_ORIGIN):
        return None
    rel = url[len(ASSET_ORIGIN):].split('?', 1)[0].split('#', 1)[0]
    try:
        from urllib.parse import unquote
        target = (assets_dir / unquote(rel)).resolve()
        root = assets_dir.resolve()
    except (OSError, ValueError):
        return None
    if root not in target.parents or target.suffix.lower() not in ASSET_TYPES or not target.is_file() \
            or target.stat().st_size > MAX_ASSET_BYTES:
        return None
    return target


def _router(assets_dir: Path | None):
    def handle(route) -> None:
        """Nothing leaves the machine. The page's own style sheets, images and fonts can be served from its folder
        (when one is given); a navigation (meta refresh, frame src) gets "204 No Content", which browsers treat as
        'stay on this page'; every other request is aborted."""
        try:
            local = _local_asset(route.request.url, assets_dir)
            if local is not None:
                ctype = mimetypes.guess_type(local.name)[0] or 'application/octet-stream'
                route.fulfill(status=200, body=local.read_bytes(), headers={'Content-Type': ctype})
            elif route.request.is_navigation_request():
                route.fulfill(status=204, body='')
            else:
                route.abort()
        except Exception:  # noqa: BLE001 - the request may already be gone
            pass
    return handle


def scan_html(html: str, best_practice: bool = False, assets_dir: Path | None = None) -> ScanResult:
    """Scan with the WCAG A/AA rules; best_practice=True also runs axe's best-practice rules.

    Nothing on the page ever runs (see htmlsource.scan_copy). assets_dir, when given, is the folder the page's own
    relative style sheets, images and fonts are loaded from; nothing outside it can be read."""
    if not AXE_PATH.is_file():
        raise ScanError('axe-core not installed. Run `npm install` in the project directory first.')
    try:
        with sync_playwright() as playwright:
            launch_args = {'headless': True}
            # Optional override for environments with a system Chromium installation.
            if os.getenv('ACCESSLOOP_CHROMIUM_EXECUTABLE'):
                launch_args['executable_path'] = os.environ['ACCESSLOOP_CHROMIUM_EXECUTABLE']
            browser = playwright.chromium.launch(**launch_args)
            try:
                context = browser.new_context(service_workers='block')
                # Demo accepts trusted static pages. Block all external resource requests.
                context.route('**/*', _router(Path(assets_dir) if assets_dir else None))
                page = context.new_page()
                page.set_default_timeout(10000)
                # Tag every start tag with data-al-uid so each finding maps to an exact source element.
                copy = scan_copy(Doc(html), ASSET_ORIGIN if assets_dir else None)
                page.set_content(copy, wait_until='load', timeout=15000)
                # Injected through the DevTools protocol, which the page's script-blocking policy does not apply to.
                page.evaluate(AXE_PATH.read_text(encoding='utf-8') + '\n;0')
                data = page.evaluate('''async (tags) => {
                    const res = await window.axe.run(document, {
                        runOnly: { type: 'tag', values: tags },
                        iframes: false,   // frame contents are never loaded (all requests are blocked)
                        rules: { 'frame-tested': { enabled: false }, 'frame-focusable-content': { enabled: false } },
                        resultTypes: ['violations', 'incomplete', 'passes']
                    });
                    for (const v of res.violations.concat(res.incomplete)) {
                        for (const n of v.nodes) {
                            let uid = null;
                            try {
                                const sel = Array.isArray(n.target) ? n.target[0] : null;
                                const el = typeof sel === 'string' ? document.querySelector(sel) : null;
                                if (el) uid = el.getAttribute('data-al-uid');
                            } catch (e) { uid = null; }
                            n.uid = uid;
                        }
                    }
                    return res;
                }''', BEST_PRACTICE_TAGS if best_practice else TAGS)
                return ScanResult.from_axe(data)
            finally:
                browser.close()
    except ScanError:
        raise
    except Exception as error:
        raise ScanError(f'Browser scan failed: {error}') from error
