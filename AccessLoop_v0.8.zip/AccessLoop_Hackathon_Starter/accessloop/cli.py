"""AccessLoop command line: scan files or folders (text, JSON or SARIF for CI), fix with approval, verify audit logs.

    python -m accessloop scan page.html                      # one page, readable summary
    python -m accessloop scan site/ --format sarif --out a11y.sarif --fail-on serious
    python -m accessloop fix page.html --out fixed.html      # asks before every change (interactive)
    python -m accessloop fix page.html --out fixed.html --approve-auto --reviewer "A. Rao"   # CI: auto fixes only
    python -m accessloop audit verify fixed.audit.jsonl

Exit codes: 0 = nothing at or above --fail-on, 1 = findings at or above --fail-on, 2 = a page was refused or could
not be scanned, 64 = bad command-line usage.
"""
from __future__ import annotations
import argparse
import json
import re
import shutil
import sys
import tempfile
from collections import Counter
from pathlib import Path

from . import __version__
from .htmlsource import Doc
from .ledger import verify as verify_ledger
from .models import Finding, ScanResult
from .planner import plan
from .workflow import Workflow, WorkflowError, approve_all, read_source, validate_source

IMPACT_ORDER = ['minor', 'moderate', 'serious', 'critical']
SARIF_LEVEL = {'critical': 'error', 'serious': 'error', 'moderate': 'warning', 'minor': 'note'}
EXIT_OK, EXIT_FINDINGS, EXIT_ERROR, EXIT_USAGE = 0, 1, 2, 64


# ---- scanning ---------------------------------------------------------------------------------------------
def _files(paths: list[str]) -> list[Path]:
    out: list[Path] = []
    for raw in paths:
        p = Path(raw)
        if p.is_dir():
            out += sorted(x for x in p.rglob('*') if x.suffix.lower() in {'.html', '.htm'} and x.is_file()
                          and 'node_modules' not in x.parts and not any(part.startswith('.') for part in x.parts))
        elif p.is_file():
            out.append(p)
        else:
            raise FileNotFoundError(f'No such file or folder: {raw}')
    return out


def _line_of(doc: Doc, f: Finding) -> int | None:
    el = doc.by_uid.get(f.uid) if f.uid is not None else None
    return doc.source.count('\n', 0, el.start) + 1 if el is not None else None


def scan_file(path: Path, best_practice: bool, scanner=None, allow_scripts: bool = False,
              assets_dir: str | None = None) -> dict:
    from .scanner import scan_html
    scanner = scanner or scan_html
    source = read_source(path)
    try:
        validate_source(source, allow_scripts=allow_scripts)
    except WorkflowError as error:
        return {'file': path.as_posix(), 'status': 'refused', 'error': str(error), 'findings': []}
    options: dict = {'best_practice': True} if best_practice else {}
    if scanner is scan_html:
        # The page's own style sheets and images: from --assets-dir, or the page's folder. Nothing outside it is read.
        options['assets_dir'] = Path(assets_dir) if assets_dir else path.parent
    try:
        result: ScanResult = scanner(source, **options)
    except Exception as error:  # noqa: BLE001 - reported per file, the run continues
        return {'file': path.as_posix(), 'status': 'error', 'error': str(error), 'findings': []}
    doc = Doc(source)
    fixable = {p.finding_index: p for p in plan(source, result.items)}
    findings = []
    for i, f in enumerate(result.items):
        p = fixable.get(i)
        findings.append({'rule': f.rule_id, 'impact': f.impact, 'kind': f.kind, 'selector': f.selector, 'help': f.help,
                         'line': _line_of(doc, f), 'html': f.html[:200],
                         'fix': None if p is None else ('needs reviewer text' if p.needs_input else 'automatic')})
    scripts = bool(re.search(r'<script\b|\son[a-z]+\s*=', source, re.I))
    return {'file': path.as_posix(), 'status': 'scanned', 'findings': findings, 'scripts_not_run': scripts,
            'violations': len(result.findings), 'needs_review': len(result.reviews), 'passed_rules': result.passed_rules}


def _at_or_above(impact: str, threshold: str) -> bool:
    if threshold == 'none':
        return False
    if threshold == 'any':
        return True
    return IMPACT_ORDER.index(impact) >= IMPACT_ORDER.index(threshold) if impact in IMPACT_ORDER else True


def to_sarif(results: list[dict], rules_info: dict) -> dict:
    used = sorted({f['rule'] for r in results for f in r['findings']})
    rules = []
    for rid in used:
        info = rules_info.get(rid, {})
        rules.append({
            'id': rid, 'name': rid,
            'shortDescription': {'text': info.get('title', rid)},
            'fullDescription': {'text': info.get('description', info.get('title', rid))},
            'helpUri': info.get('help_url') or f'https://dequeuniversity.com/rules/axe/4.10/{rid}',
            'properties': {'tags': ['accessibility'] + [f'WCAG {c}' for c in info.get('wcag', [])],
                           'wcagLevel': info.get('level', ''), 'accessloopHandling': info.get('handling', '')},
        })
    index = {r['id']: i for i, r in enumerate(rules)}
    out = []
    for r in results:
        for f in r['findings']:
            region = {'snippet': {'text': f['html']}}
            if f['line']:
                region['startLine'] = f['line']
            text = f['help'].rstrip('.') + '.' + (' axe needs a human to review this.' if f['kind'] == 'review' else '')
            if f['fix']:
                text += f' AccessLoop fix available: {f["fix"]}.'
            out.append({
                'ruleId': f['rule'], 'ruleIndex': index[f['rule']],
                'level': 'note' if f['kind'] == 'review' else SARIF_LEVEL.get(f['impact'], 'warning'),
                'message': {'text': text},
                'locations': [{'physicalLocation': {'artifactLocation': {'uri': r['file']}, 'region': region},
                               'logicalLocations': [{'fullyQualifiedName': f['selector'], 'kind': 'element'}]}],
                'properties': {'impact': f['impact'], 'kind': f['kind'], 'fixAvailable': f['fix'] or 'none'},
            })
    notifications = [{'level': 'error', 'message': {'text': f'{r["file"]}: {r["error"]}'}}
                     for r in results if r['status'] != 'scanned']
    return {
        '$schema': 'https://json.schemastore.org/sarif-2.1.0.json', 'version': '2.1.0',
        'runs': [{
            'tool': {'driver': {'name': 'AccessLoop', 'version': __version__, 'semanticVersion': __version__,
                                'informationUri': 'https://github.com/', 'rules': rules}},
            'results': out,
            'invocations': [{'executionSuccessful': not notifications, 'toolExecutionNotifications': notifications}],
        }],
    }


def _text_report(results: list[dict], threshold: str) -> str:
    lines = []
    for r in results:
        if r['status'] != 'scanned':
            lines.append(f'✗ {r["file"]}: {r["status"].upper()} - {r["error"]}')
            continue
        fixable = sum(1 for f in r['findings'] if f['fix'])
        lines.append(f'• {r["file"]}: {r["violations"]} violation node(s), {r["needs_review"]} needs review, '
                     f'{fixable} with an AccessLoop fix' + (' (scripts present, not run)' if r.get('scripts_not_run') else ''))
        for f in sorted(r['findings'], key=lambda f: (-IMPACT_ORDER.index(f['impact']) if f['impact'] in IMPACT_ORDER else 0,
                                                       f['line'] or 0)):
            mark = '!' if f['kind'] == 'violation' and _at_or_above(f['impact'], threshold) else ' '
            where = f'line {f["line"]}' if f['line'] else f['selector']
            fix = f' [fix: {f["fix"]}]' if f['fix'] else ''
            review = ' (needs review)' if f['kind'] == 'review' else ''
            lines.append(f'   {mark} {f["impact"]:<8} {f["rule"]:<30} {where}{review}{fix}')
    scanned = [r for r in results if r['status'] == 'scanned']
    total = Counter(f['impact'] for r in scanned for f in r['findings'] if f['kind'] == 'violation')
    lines += ['', f'{len(results)} page(s): {len(scanned)} scanned, {len(results) - len(scanned)} refused or failed. '
              + 'Violations by severity: ' + (', '.join(f'{k} {total[k]}' for k in reversed(IMPACT_ORDER) if total[k]) or 'none')
              + '.']
    return '\n'.join(lines)


def cmd_scan(args) -> int:
    try:
        files = _files(args.paths)
    except FileNotFoundError as error:
        print(error, file=sys.stderr)
        return EXIT_USAGE
    if not files:
        print('No .html files found.', file=sys.stderr)
        return EXIT_USAGE
    results = []
    for path in files:
        if not args.quiet and args.format == 'text':
            print(f'Scanning {path} …', file=sys.stderr)
        results.append(scan_file(path, args.best_practice, allow_scripts=args.allow_scripts, assets_dir=args.assets_dir))
    if args.format == 'sarif':
        from .catalog import build
        info = {r['rule_id']: r for r in build()['rules']}
        text = json.dumps(to_sarif(results, info), indent=2, ensure_ascii=False)
    elif args.format == 'json':
        text = json.dumps({'tool': 'AccessLoop', 'version': __version__, 'best_practice': args.best_practice,
                           'results': results}, indent=2, ensure_ascii=False)
    else:
        text = _text_report(results, args.fail_on)
    if args.out:
        Path(args.out).write_text(text + '\n', encoding='utf-8')
        print(f'Wrote {args.out}', file=sys.stderr)
    else:
        print(text)
    if any(r['status'] != 'scanned' for r in results):
        return EXIT_ERROR
    over = any(f['kind'] == 'violation' and _at_or_above(f['impact'], args.fail_on) for r in results for f in r['findings'])
    return EXIT_FINDINGS if over else EXIT_OK


# ---- fixing -----------------------------------------------------------------------------------------------
def _ask(prompt: str) -> str:
    try:
        return input(prompt)
    except EOFError:
        return ''


def _ask_values(p) -> dict | None:
    values: dict = {}
    for fld in p.fields:
        if fld['kind'] == 'select':
            print(f'   {fld["label"]}')
            for i, (v, label) in enumerate(fld['options'], start=1):
                print(f'     {i}. {label}')
            pick = _ask('   Choose a number (blank = skip this fix): ').strip()
            if not pick.isdigit() or not 1 <= int(pick) <= len(fld['options']):
                return None
            values[fld['name']] = fld['options'][int(pick) - 1][0]
        elif fld['kind'] == 'checkbox':
            values[fld['name']] = _ask(f'   {fld["label"]}? [y/N] ').strip().lower() in {'y', 'yes'}
        else:
            text = _ask(f'   {fld["label"]} (blank = skip): ').strip()
            if not text and fld.get('required', True) and not any(f['kind'] == 'checkbox' for f in p.fields):
                return None
            values[fld['name']] = text
    return values


def cmd_fix(args) -> int:
    src = Path(args.file)
    if not src.is_file():
        print(f'No such file: {src}', file=sys.stderr)
        return EXIT_USAGE
    out = Path(args.out)
    if out.resolve() == src.resolve():
        print('Write the repaired page to a new file (--out); the original is never overwritten.', file=sys.stderr)
        return EXIT_USAGE
    interactive = not args.approve_auto
    if interactive and not sys.stdin.isatty() and not args.force_interactive:
        print('No terminal to ask for approval. Use --approve-auto with --reviewer for unattended auto-only fixing.',
              file=sys.stderr)
        return EXIT_USAGE
    if args.approve_auto and not (args.reviewer or '').strip():
        print('--approve-auto needs --reviewer NAME: every approval is recorded against a person.', file=sys.stderr)
        return EXIT_USAGE
    reviewer = (args.reviewer or '').strip() or None
    with tempfile.TemporaryDirectory() as tmp:
        engine = Workflow(Path(tmp))
        try:
            engine.load(read_source(src), allow_scripts=args.allow_scripts, assets_dir=src.parent)
            scan = engine.scan(language=args.language, best_practice=args.best_practice)
        except Exception as error:  # noqa: BLE001
            print(f'Could not process {src}: {error}', file=sys.stderr)
            return EXIT_ERROR
        print(f'{src}: {len(scan.findings)} violation node(s), {len(scan.reviews)} needs review, '
              f'{len(engine.proposals)} fix proposal(s).')
        decided: set[tuple] = set()
        stats = Counter()
        if args.approve_auto:
            for r in approve_all(engine, lambda p: None, reviewer=reviewer, language=args.language):
                key = 'needs your text (skipped)' if r['status'] == 'skipped' else r['status']
                stats[key] += r['size'] if r['status'] == 'verified' else 1
                if r['status'] not in ('verified', 'skipped'):
                    print(f'   {r["rule"]} ({r["mode"]}): {r["status"]}: {r["detail"]}')
        for _ in range(0 if args.approve_auto else 500):
            todo = [p for p in engine.proposals if (p.rule_id, p.selector, p.before) not in decided]
            if not todo:
                break
            p = todo[0]
            decided.add((p.rule_id, p.selector, p.before))
            if args.approve_auto:
                if p.needs_input:
                    stats['needs your text (skipped)'] += 1
                    continue
                values = None
            else:
                print(f'\n[{p.rule_id}] line {p.line}: {p.explanation}\n   evidence: {p.evidence}')
                print(f'   - {p.before[:160]}\n   + {p.after[:160]}')
                if _ask('   Apply this fix? [y/N] ').strip().lower() not in {'y', 'yes'}:
                    engine.reject(p.proposal_id, reviewer)
                    stats['rejected'] += 1
                    continue
                values = _ask_values(p) if p.needs_input else None
                if p.needs_input and values is None:
                    engine.reject(p.proposal_id, reviewer)
                    stats['skipped (no text given)'] += 1
                    continue
            try:
                outcome = engine.apply(p.proposal_id, approved=True, language=args.language, values=values, reviewer=reviewer)
            except WorkflowError as error:
                print(f'   refused: {error}')
                stats['refused'] += 1
                continue
            stats[outcome.status] += 1
            if not args.approve_auto or outcome.status != 'verified':
                print(f'   {outcome.status}: {outcome.detail}')
        out.write_text(engine.current_html, encoding='utf-8', newline='')
        log = out.with_suffix('.audit.jsonl')
        shutil.copyfile(Path(tmp) / 'audit.jsonl', log)
        final = engine.current_scan
        print(f'\nWrote {out} and its audit log {log}.')
        print('Decisions: ' + (', '.join(f'{k} {v}' for k, v in stats.items()) or 'none') + '.')
        if final is not None:
            print(f'Violations: {len(scan.findings)} → {len(final.findings)}; needs review: {len(scan.reviews)} → {len(final.reviews)}.')
        return EXIT_OK if final is not None and not final.findings else EXIT_FINDINGS


def cmd_audit(args) -> int:
    ok, message, records = verify_ledger(Path(args.log))
    print(('OK: ' if ok else 'TAMPERING DETECTED: ') + message)
    if ok and records:
        print(f'Head hash: {records[-1]["hash"]}')
    return EXIT_OK if ok else EXIT_FINDINGS


def build_parser() -> argparse.ArgumentParser:
    ap = argparse.ArgumentParser(prog='accessloop', description='Find, fix and verify accessibility problems in static HTML.')
    ap.add_argument('--version', action='version', version=f'AccessLoop {__version__}')
    sub = ap.add_subparsers(dest='command', required=True)

    s = sub.add_parser('scan', help='scan HTML files or folders')
    s.add_argument('paths', nargs='+')
    s.add_argument('--best-practice', action='store_true', help='also run axe best-practice rules')
    s.add_argument('--allow-scripts', action='store_true',
                   help='accept pages with scripts; the scripts are never run, so content built by JavaScript is not checked')
    s.add_argument('--assets-dir', help="folder to load the pages' own CSS/images/fonts from (default: each page's folder)")
    s.add_argument('--format', choices=['text', 'json', 'sarif'], default='text')
    s.add_argument('--out', help='write the report to this file')
    s.add_argument('--fail-on', choices=['critical', 'serious', 'moderate', 'minor', 'any', 'none'], default='serious',
                   help='exit 1 when any violation is at or above this severity (default: serious)')
    s.add_argument('--quiet', action='store_true')
    s.set_defaults(func=cmd_scan)

    f = sub.add_parser('fix', help='propose fixes, apply the ones you approve, re-verify each one')
    f.add_argument('file')
    f.add_argument('--out', required=True, help='repaired copy (the original is never modified)')
    f.add_argument('--language', default='en', help='page language to use if the page has none (default: en)')
    f.add_argument('--best-practice', action='store_true')
    f.add_argument('--allow-scripts', action='store_true', help='accept pages with scripts (never run)')
    f.add_argument('--approve-auto', action='store_true',
                   help='unattended: apply only fixes that need no typed text; skip the rest (needs --reviewer)')
    f.add_argument('--reviewer', help='name recorded with every decision')
    f.add_argument('--force-interactive', action='store_true', help=argparse.SUPPRESS)
    f.set_defaults(func=cmd_fix)

    a = sub.add_parser('audit', help='audit log tools')
    a_sub = a.add_subparsers(dest='audit_command', required=True)
    v = a_sub.add_parser('verify', help='check an audit log has not been edited')
    v.add_argument('log')
    v.set_defaults(func=cmd_audit)
    return ap


def main(argv: list[str] | None = None) -> int:
    parser = build_parser()
    try:
        args = parser.parse_args(argv)
    except SystemExit as exit_:
        return EXIT_USAGE if exit_.code not in (0, None) else EXIT_OK
    return args.func(args)


if __name__ == '__main__':
    raise SystemExit(main())
