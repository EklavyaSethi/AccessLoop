"""Treat improvements as local evidence, never as a full WCAG compliance claim."""
from .models import ScanResult


def verify(before: ScanResult, after: ScanResult, target_rule: str) -> tuple[bool, str]:
    """A fix passes only if its rule improves (violations plus needs-review nodes) and no rule's violations increase."""
    old, new = before.counts(), after.counts()
    old_t = old[target_rule] + before.review_counts()[target_rule]
    new_t = new[target_rule] + after.review_counts()[target_rule]
    if new_t >= old_t:
        return False, f'Target rule {target_rule} did not improve ({old_t} → {new_t}).'
    notes = []
    for rule in sorted(set(old) | set(new)):
        if new[rule] > old[rule]:
            if rule == 'region' and target_rule != 'region' and new['landmark-one-main'] > 0 and old['landmark-one-main'] > 0:
                # The page has no main landmark, so every piece of content is "outside a region". New visible text
                # (a heading, a label) adds a node to that page-level finding without creating a new kind of problem.
                notes.append(f'region {old[rule]} → {new[rule]} (page has no main landmark yet; fix that to clear all region items)')
                continue
            return False, f'Automated regression: {rule} increased ({old[rule]} → {new[rule]}).'
    extra = ' Note: ' + '; '.join(notes) + '.' if notes else ''
    return True, f'Target rule improved ({old_t} → {new_t}); no increase in detected rule counts.{extra}'
