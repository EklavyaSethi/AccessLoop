# AccessLoop issue catalogue

Generated from the real axe-core engine (version 4.14.0) and the 55 WCAG 2.2 Level A and AA success criteria. Regenerate with `python -m accessloop.catalog`.

> **Scope note.** No list can contain every possible accessibility barrier, because usability for real people is not a finite checklist. This catalogue is complete against the two standards that matter for compliance work: every rule the axe engine can detect, and every WCAG 2.2 A/AA criterion. Where a tool cannot test a criterion, it is listed as manual-only rather than left out.

## 1. Summary

- axe rules in the engine: **105**. Run by AccessLoop today: **64**. Not run: **41**.
- Handling today: **3** with a live auto-fix, **8** planned deterministic fixes, **31** planned reviewer-assisted fixes, **49** guidance-only, **14** excluded (deprecated, experimental or AAA).
- WCAG 2.2 A + AA criteria: **55**. At least partly testable by axe: **23**. Not testable by axe at all: **32**, of which **10** could get an AccessLoop-built browser or site check.
- **Gap found:** 27 best-practice rules are not run by the current scanner (heading order, landmarks, skip link, tab order and more). Auditors usually report these, so a best-practice mode is on the build list.

## 2. How AccessLoop handles each rule

| Handling | Meaning |
|---|---|
| `live` | Auto-fix available now (human-approved) |
| `auto` | Planned: deterministic fix |
| `assisted` | Planned: fix with reviewer input |
| `guided` | Detected: guidance only, no edit |
| `excluded` | Not scanned: reason given |

Priority: **P1** = most common real-world failures (WebAIM top six) and banking-form needs; **P2** = next.

## 3. Live auto-fixes (3)

| Rule | WCAG | Level | Priority | Scanned today | What AccessLoop does |
|---|---|---|---|---|---|
| `button-name` | 4.1.2 | A | P1 | yes | Un-hides visible button text wrongly marked aria-hidden. Icon-only buttons are escalated to a human. |
| `html-has-lang` | 3.1.1 | A | P1 | yes | Adds lang="<reviewer-chosen code>" to <html>. |
| `label` | 4.1.2 | A | P1 | yes | Links an immediately adjacent visible <label> to its unique <input> with for=. Other label layouts are planned. |

## 4. Planned: deterministic fixes (8)

| Rule | WCAG | Level | Priority | Scanned today | What AccessLoop does |
|---|---|---|---|---|---|
| `aria-hidden-body` | 1.3.1, 4.1.2 | A | P2 | yes | Remove aria-hidden from <body>. |
| `blink` | 2.2.2 | A | P2 | yes | Unwrap the deprecated <blink> element, keeping its text. |
| `html-xml-lang-mismatch` | 3.1.1 | A | P2 | yes | Make xml:lang match the lang attribute. |
| `marquee` | 2.2.2 | A | P2 | yes | Unwrap the deprecated <marquee> element, keeping its text. |
| `meta-viewport` | 1.4.4 | AA | P1 | yes | Remove user-scalable=no and restrictive maximum-scale so users can zoom. |
| `meta-viewport-large` | - | best-practice | P2 | no | Raise or remove maximum-scale values below 5. |
| `scope-attr-valid` | - | best-practice | P2 | no | Remove invalid scope values from table cells. |
| `scrollable-region-focusable` | 2.1.1, 2.1.3 | A | P2 | yes | Add tabindex="0" so keyboard users can scroll the region. |

## 5. Planned: reviewer-assisted fixes (31)

| Rule | WCAG | Level | Priority | Scanned today | What AccessLoop does |
|---|---|---|---|---|---|
| `area-alt` | 2.4.4, 4.1.2 | A | P2 | yes | Reviewer supplies alt text for image-map areas. |
| `aria-command-name` | 4.1.2 | A | P2 | yes | Reviewer supplies an accessible name (aria-label) for the control. |
| `aria-dialog-name` | - | best-practice | P2 | no | Reviewer supplies a dialog name (aria-label / aria-labelledby). |
| `aria-input-field-name` | 4.1.2 | A | P2 | yes | Reviewer supplies an accessible name for the custom input. |
| `aria-meter-name` | 1.1.1 | A | P2 | yes | Reviewer supplies a name for the meter. |
| `aria-progressbar-name` | 1.1.1 | A | P2 | yes | Reviewer supplies a name for the progress bar. |
| `aria-tab-name` | 4.1.2 | A | P2 | yes | Reviewer supplies a name for the tab. |
| `aria-toggle-field-name` | 4.1.2 | A | P2 | yes | Reviewer supplies a name for the toggle. |
| `aria-tooltip-name` | 4.1.2 | A | P2 | yes | Reviewer supplies a name for the tooltip. |
| `aria-treeitem-name` | - | best-practice | P2 | no | Reviewer supplies a name for the tree item. |
| `autocomplete-valid` | 1.3.5 | AA | P1 | yes | Suggest a valid autocomplete token from the field type/name (KYC forms); reviewer confirms. |
| `bypass` | 2.4.1 | A | P2 | yes | Insert a "Skip to main content" link and target; reviewer confirms placement. |
| `color-contrast` | 1.4.3 | AA | P1 | yes | Compute the nearest colour of the same hue that reaches 4.5:1 (3:1 for large text); reviewer approves the CSS change. |
| `document-title` | 2.4.2 | A | P1 | yes | Propose a <title> from the page heading; reviewer edits and approves. |
| `frame-title` | 4.1.2 | A | P2 | yes | Reviewer supplies a title for the frame. |
| `html-lang-valid` | 3.1.1 | A | P1 | yes | Replace an invalid lang value with a reviewer-chosen code. |
| `image-alt` | 1.1.1 | A | P1 | yes | Reviewer marks the image decorative (alt="") or supplies alt text; AI may suggest wording. |
| `input-button-name` | 4.1.2 | A | P1 | yes | Reviewer supplies a value/label for the button input. |
| `input-image-alt` | 1.1.1, 4.1.2 | A | P2 | yes | Reviewer supplies alt text for the image button. |
| `label-content-name-mismatch` | 2.5.3 | A | P2 | yes | Align the accessible name with the visible text; reviewer approves. |
| `label-title-only` | - | best-practice | P2 | no | Replace a title-only label with a real <label>; reviewer approves. |
| `link-in-text-block` | 1.4.1 | A | P2 | yes | Add an underline (or other non-colour cue) to in-text links via CSS; reviewer approves. |
| `link-name` | 2.4.4, 4.1.2 | A | P1 | yes | Reviewer supplies link text (aria-label) or marks it for rewrite. |
| `object-alt` | 1.1.1 | A | P2 | yes | Reviewer supplies alternative text for the <object>. |
| `role-img-alt` | 1.1.1 | A | P2 | yes | Reviewer supplies alt text for the role="img" element. |
| `select-name` | 4.1.2 | A | P1 | yes | Link an adjacent <label> or add an aria-label supplied by the reviewer. |
| `skip-link` | - | best-practice | P2 | no | Fix the skip link target; reviewer confirms. |
| `summary-name` | 4.1.2 | A | P2 | yes | Reviewer supplies visible text for the <summary>. |
| `svg-img-alt` | 1.1.1 | A | P2 | yes | Reviewer supplies a name (<title>/aria-label) for the SVG image. |
| `tabindex` | - | best-practice | P2 | no | Replace positive tabindex values with 0 or remove them; reviewer checks the resulting tab order. |
| `valid-lang` | 3.1.2 | AA | P1 | yes | Replace an invalid lang on a page section with a reviewer-chosen code. |

## 6. Guidance only (49)

Needs a structure, design or content decision that a template cannot make safely, so AccessLoop reports it with the axe guidance link and does not edit it.

| Rule | WCAG | Level | Scanned today |
|---|---|---|---|
| `accesskeys` | - | best-practice | no |
| `aria-allowed-attr` | 4.1.2 | A | yes |
| `aria-allowed-role` | - | best-practice | no |
| `aria-braille-equivalent` | 4.1.2 | A | yes |
| `aria-conditional-attr` | 4.1.2 | A | yes |
| `aria-deprecated-role` | 4.1.2 | A | yes |
| `aria-hidden-focus` | 4.1.2 | A | yes |
| `aria-prohibited-attr` | 4.1.2 | A | yes |
| `aria-required-attr` | 4.1.2 | A | yes |
| `aria-required-children` | 1.3.1 | A | yes |
| `aria-required-parent` | 1.3.1 | A | yes |
| `aria-roles` | 4.1.2 | A | yes |
| `aria-text` | - | best-practice | no |
| `aria-valid-attr` | 4.1.2 | A | yes |
| `aria-valid-attr-value` | 4.1.2 | A | yes |
| `avoid-inline-spacing` | 1.4.12 | AA | yes |
| `definition-list` | 1.3.1 | A | yes |
| `dlitem` | 1.3.1 | A | yes |
| `duplicate-id-aria` | 4.1.2 | A | yes |
| `empty-heading` | - | best-practice | no |
| `empty-table-header` | - | best-practice | no |
| `form-field-multiple-labels` | 3.3.2 | A | yes |
| `frame-focusable-content` | 2.1.1 | A | yes |
| `frame-tested` | - | best-practice | no |
| `frame-title-unique` | 4.1.2 | A | yes |
| `heading-order` | - | best-practice | no |
| `image-redundant-alt` | - | best-practice | no |
| `landmark-banner-is-top-level` | - | best-practice | no |
| `landmark-contentinfo-is-top-level` | - | best-practice | no |
| `landmark-main-is-top-level` | - | best-practice | no |
| `landmark-no-duplicate-banner` | - | best-practice | no |
| `landmark-no-duplicate-contentinfo` | - | best-practice | no |
| `landmark-no-duplicate-main` | - | best-practice | no |
| `landmark-one-main` | - | best-practice | no |
| `landmark-unique` | - | best-practice | no |
| `list` | 1.3.1 | A | yes |
| `listitem` | 1.3.1 | A | yes |
| `meta-refresh` | 2.2.1 | A | yes |
| `nested-interactive` | 4.1.2 | A | yes |
| `no-autoplay-audio` | 1.4.2 | A | yes |
| `page-has-heading-one` | - | best-practice | no |
| `presentation-role-conflict` | - | best-practice | no |
| `region` | - | best-practice | no |
| `server-side-image-map` | 2.1.1 | A | yes |
| `table-duplicate-name` | - | best-practice | no |
| `target-size` | 2.5.8 | AA | yes |
| `td-headers-attr` | 1.3.1 | A | yes |
| `th-has-data-cells` | 1.3.1 | A | yes |
| `video-caption` | 1.2.2 | A | yes |

## 7. Excluded from scanning (14)

| Rule | Reason |
|---|---|
| `aria-roledescription` | Deprecated by axe. |
| `audio-caption` | Deprecated by axe. |
| `color-contrast-enhanced` | Level AAA only; outside the WCAG AA target. |
| `css-orientation-lock` | Experimental in axe (off by default). |
| `duplicate-id` | Deprecated by axe (WCAG 4.1.1 Parsing was removed in WCAG 2.2). |
| `duplicate-id-active` | Deprecated by axe (WCAG 4.1.1 Parsing was removed in WCAG 2.2). |
| `focus-order-semantics` | Experimental in axe (off by default). |
| `hidden-content` | Experimental in axe (off by default). |
| `identical-links-same-purpose` | Level AAA only; outside the WCAG AA target. |
| `landmark-complementary-is-top-level` | Deprecated by axe. |
| `meta-refresh-no-exceptions` | Level AAA only; outside the WCAG AA target. |
| `p-as-heading` | Experimental in axe (off by default). |
| `table-fake-caption` | Experimental in axe (off by default). |
| `td-has-header` | Experimental in axe (off by default). |

## 8. All 55 WCAG 2.2 A + AA criteria

| Criterion | Name | Level | axe rules | Next step | Why it matters for BFSI |
|---|---|---|---|---|---|
| 1.1.1 | Non-text Content | A | `aria-meter-name`, `aria-progressbar-name`, `image-alt`, `input-image-alt`, `object-alt`, `role-img-alt`, `svg-img-alt` | Partly testable by axe; manual checks still needed. |  |
| 1.2.1 | Audio-only and Video-only (Prerecorded) | A | `audio-caption` | Partly testable by axe; manual checks still needed. |  |
| 1.2.2 | Captions (Prerecorded) | A | `video-caption` | Partly testable by axe; manual checks still needed. |  |
| 1.2.3 | Audio Description or Media Alternative (Prerecorded) | A | **none (manual-only)** | Needs a human check; AccessLoop lists it in the manual checklist. |  |
| 1.3.1 | Info and Relationships | A | `aria-hidden-body`, `aria-required-children`, `aria-required-parent`, `definition-list`, `dlitem`, `list`, `listitem`, `p-as-heading`, `table-fake-caption`, `td-has-header`, `td-headers-attr`, `th-has-data-cells` | Partly testable by axe; manual checks still needed. |  |
| 1.3.2 | Meaningful Sequence | A | **none (manual-only)** | Needs a human check; AccessLoop lists it in the manual checklist. |  |
| 1.3.3 | Sensory Characteristics | A | **none (manual-only)** | Needs a human check; AccessLoop lists it in the manual checklist. |  |
| 1.4.1 | Use of Color | A | `link-in-text-block` | Partly testable by axe; manual checks still needed. |  |
| 1.4.2 | Audio Control | A | `no-autoplay-audio` | Partly testable by axe; manual checks still needed. |  |
| 2.1.1 | Keyboard | A | `frame-focusable-content`, `scrollable-region-focusable`, `server-side-image-map` | Partly testable by axe; manual checks still needed. |  |
| 2.1.2 | No Keyboard Trap | A | **none (manual-only)** | Tab through the page and flag any element focus cannot leave. |  |
| 2.1.4 | Character Key Shortcuts | A | **none (manual-only)** | Needs a human check; AccessLoop lists it in the manual checklist. |  |
| 2.2.1 | Timing Adjustable | A | `meta-refresh` | Partly testable by axe; manual checks still needed. | Banking sessions time out; users need warning and a way to extend. |
| 2.2.2 | Pause, Stop, Hide | A | `blink`, `marquee` | Partly testable by axe; manual checks still needed. |  |
| 2.3.1 | Three Flashes or Below Threshold | A | **none (manual-only)** | Needs a human check; AccessLoop lists it in the manual checklist. |  |
| 2.4.1 | Bypass Blocks | A | `bypass` | Partly testable by axe; manual checks still needed. |  |
| 2.4.2 | Page Titled | A | `document-title` | Partly testable by axe; manual checks still needed. |  |
| 2.4.3 | Focus Order | A | **none (manual-only)** | Record the Tab order and show it for human review. |  |
| 2.4.4 | Link Purpose (In Context) | A | `area-alt`, `link-name` | Partly testable by axe; manual checks still needed. |  |
| 2.5.1 | Pointer Gestures | A | **none (manual-only)** | Needs a human check; AccessLoop lists it in the manual checklist. |  |
| 2.5.2 | Pointer Cancellation | A | **none (manual-only)** | Needs a human check; AccessLoop lists it in the manual checklist. |  |
| 2.5.3 | Label in Name | A | `label-content-name-mismatch` | Partly testable by axe; manual checks still needed. |  |
| 2.5.4 | Motion Actuation | A | **none (manual-only)** | Needs a human check; AccessLoop lists it in the manual checklist. |  |
| 3.1.1 | Language of Page | A | `html-has-lang`, `html-lang-valid`, `html-xml-lang-mismatch` | Partly testable by axe; manual checks still needed. |  |
| 3.2.1 | On Focus | A | **none (manual-only)** | Needs a human check; AccessLoop lists it in the manual checklist. |  |
| 3.2.2 | On Input | A | **none (manual-only)** | Needs a human check; AccessLoop lists it in the manual checklist. |  |
| 3.2.6 | Consistent Help | A | **none (manual-only)** | In whole-site mode, check help links appear in the same place on every page. |  |
| 3.3.1 | Error Identification | A | **none (manual-only)** | Needs a human check; AccessLoop lists it in the manual checklist. | Form errors on KYC, payments and claims must be identified in text. |
| 3.3.2 | Labels or Instructions | A | `form-field-multiple-labels` | Partly testable by axe; manual checks still needed. | Every field on an application form needs a visible label or instruction. |
| 3.3.7 | Redundant Entry | A | **none (manual-only)** | Needs a human check; AccessLoop lists it in the manual checklist. | Do not make users re-enter information already given in the same process. |
| 4.1.2 | Name, Role, Value | A | `area-alt`, `aria-allowed-attr`, `aria-braille-equivalent`, `aria-command-name`, `aria-conditional-attr`, `aria-deprecated-role`, `aria-hidden-body`, `aria-hidden-focus`, `aria-input-field-name`, `aria-prohibited-attr`, `aria-required-attr`, `aria-roledescription`, `aria-roles`, `aria-tab-name`, `aria-toggle-field-name`, `aria-tooltip-name`, `aria-valid-attr`, `aria-valid-attr-value`, `button-name`, `duplicate-id-aria`, `frame-title`, `frame-title-unique`, `input-button-name`, `input-image-alt`, `label`, `link-name`, `nested-interactive`, `select-name`, `summary-name` | Partly testable by axe; manual checks still needed. |  |
| 1.2.4 | Captions (Live) | AA | **none (manual-only)** | Needs a human check; AccessLoop lists it in the manual checklist. |  |
| 1.2.5 | Audio Description (Prerecorded) | AA | **none (manual-only)** | Needs a human check; AccessLoop lists it in the manual checklist. |  |
| 1.3.4 | Orientation | AA | `css-orientation-lock` | Partly testable by axe; manual checks still needed. |  |
| 1.3.5 | Identify Input Purpose | AA | `autocomplete-valid` | Partly testable by axe; manual checks still needed. | KYC and sign-up forms: browsers and assistive tech can auto-fill name, address, phone and email. |
| 1.4.3 | Contrast (Minimum) | AA | `color-contrast` | Partly testable by axe; manual checks still needed. |  |
| 1.4.4 | Resize Text | AA | `meta-viewport` | Partly testable by axe; manual checks still needed. |  |
| 1.4.5 | Images of Text | AA | **none (manual-only)** | Needs a human check; AccessLoop lists it in the manual checklist. |  |
| 1.4.10 | Reflow | AA | **none (manual-only)** | Render at 320 px width and flag horizontal scrolling. |  |
| 1.4.11 | Non-text Contrast | AA | **none (manual-only)** | Measure border and icon contrast of form controls against the 3:1 minimum. |  |
| 1.4.12 | Text Spacing | AA | `avoid-inline-spacing` | Partly testable by axe; manual checks still needed. |  |
| 1.4.13 | Content on Hover or Focus | AA | **none (manual-only)** | Needs a human check; AccessLoop lists it in the manual checklist. |  |
| 2.4.5 | Multiple Ways | AA | **none (manual-only)** | In whole-site mode, check there is more than one way to find pages (navigation plus search or sitemap). |  |
| 2.4.6 | Headings and Labels | AA | **none (manual-only)** | Needs a human check; AccessLoop lists it in the manual checklist. |  |
| 2.4.7 | Focus Visible | AA | **none (manual-only)** | Tab through the page and flag controls with no visible focus change. |  |
| 2.4.11 | Focus Not Obscured (Minimum) | AA | **none (manual-only)** | While tabbing, flag focused controls hidden behind sticky headers or footers. |  |
| 2.5.7 | Dragging Movements | AA | **none (manual-only)** | Needs a human check; AccessLoop lists it in the manual checklist. |  |
| 2.5.8 | Target Size (Minimum) | AA | `target-size` | Partly testable by axe; manual checks still needed. |  |
| 3.1.2 | Language of Parts | AA | `valid-lang` | Partly testable by axe; manual checks still needed. |  |
| 3.2.3 | Consistent Navigation | AA | **none (manual-only)** | In whole-site mode, compare navigation order across pages. |  |
| 3.2.4 | Consistent Identification | AA | **none (manual-only)** | In whole-site mode, compare labels of repeated components across pages. |  |
| 3.3.3 | Error Suggestion | AA | **none (manual-only)** | Needs a human check; AccessLoop lists it in the manual checklist. | Failed entries (account numbers, IFSC, PAN) need a suggested correction. |
| 3.3.4 | Error Prevention (Legal, Financial, Data) | AA | **none (manual-only)** | Needs a human check; AccessLoop lists it in the manual checklist. | Financial and legal submissions must be reversible, checked or confirmed. |
| 3.3.8 | Accessible Authentication (Minimum) | AA | **none (manual-only)** | Needs a human check; AccessLoop lists it in the manual checklist. | Login and OTP steps must not rely on memorising or transcribing codes with no alternative. |
| 4.1.3 | Status Messages | AA | **none (manual-only)** | Needs a human check; AccessLoop lists it in the manual checklist. | Transaction results and balance updates must be announced to screen readers. |

## 9. Best-practice rules the scanner does not run today

`accesskeys`, `aria-allowed-role`, `aria-dialog-name`, `aria-text`, `aria-treeitem-name`, `empty-heading`, `empty-table-header`, `frame-tested`, `heading-order`, `image-redundant-alt`, `label-title-only`, `landmark-banner-is-top-level`, `landmark-contentinfo-is-top-level`, `landmark-main-is-top-level`, `landmark-no-duplicate-banner`, `landmark-no-duplicate-contentinfo`, `landmark-no-duplicate-main`, `landmark-one-main`, `landmark-unique`, `meta-viewport-large`, `page-has-heading-one`, `presentation-role-conflict`, `region`, `scope-attr-valid`, `skip-link`, `tabindex`, `table-duplicate-name`

---
Automated tools cannot certify WCAG conformance; keyboard, screen-reader and human usability testing remain necessary.
