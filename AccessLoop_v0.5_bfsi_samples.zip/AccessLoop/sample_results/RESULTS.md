# AccessLoop sample-suite results

**10/10 cases passed** (real Chromium + axe-core, no fake scanner)

## PASS - Starter demo (regression)
`examples/student_registration.html` - Original starter page: 3 seeded rules fixed end-to-end

- Baseline counts: `{'button-name': 1, 'html-has-lang': 1, 'label': 1}`  ->  Final counts: `{}`
- verified: **button-name** `#submit-registration`  `<span aria-hidden="true">Submit registration</span>` -> `<span>Submit registration</span>`
- verified: **html-has-lang** `html`  `<html>` -> `<html lang="en">`
- verified: **label** `#email`  `<label>University email</label>` -> `<label for="email">University email</label>`
  - [x] 3 seeded rules detected
  - [x] every applied patch verified
  - [x] seeded rules cleared
  - [x] original.html never modified

## PASS - Starter ambiguous icon (regression)
`examples/ambiguous_icon_button.html` - Icon-only button must escalate

- Baseline counts: `{'button-name': 1}`  ->  Final counts: `{'button-name': 1}`
- Manual-review queue: `button-name #icon-action`
  - [x] button-name detected
  - [x] no invented label (0 proposals)
  - [x] original.html never modified

## PASS - B1 KYC onboarding
`examples/samples/01_kyc_onboarding.html` - Many instances + reject / no-approval / stale guards on a KYC form

- Baseline counts: `{'button-name': 1, 'html-has-lang': 1, 'label': 4}`  ->  Final counts: `{}`
- verified: **button-name** `#submit-kyc`  `<span aria-hidden="true">Submit KYC details</span>` -> `<span>Submit KYC details</span>`
- verified: **html-has-lang** `html`  `<html>` -> `<html lang="en">`
- verified: **label** `#kyc-name`  `<label>Full name (as on PAN)</label>` -> `<label for="kyc-name">Full name (as on PAN)</label>`
- verified: **label** `#kyc-pan`  `<label>PAN number</label>` -> `<label for="kyc-pan">PAN number</label>`
- verified: **label** `#kyc-dob`  `<label>Date of birth</label>` -> `<label for="kyc-dob">Date of birth</label>`
- verified: **label** `#kyc-mobile`  `<label>Mobile number</label>` -> `<label for="kyc-mobile">Mobile number</label>`
  - [x] html-has-lang=1, label=4, button-name=1 detected
  - [x] 6 proposals generated
  - [x] reject leaves working file byte-identical
  - [x] approved=False leaves working file byte-identical
  - [x] stale proposal blocked
  - [x] 6 patches applied, all verified
  - [x] all supported rules cleared
  - [x] total violations reach 0
  - [x] original.html never modified

## PASS - B1b Invalid language
`examples/samples/01_kyc_onboarding.html` - Bad reviewer language input

- Baseline counts: `{'button-name': 1, 'html-has-lang': 1, 'label': 4}`  ->  Final counts: `{'button-name': 1, 'html-has-lang': 1, 'label': 4}`
- Manual-review queue: `button-name #submit-kyc`, `html-has-lang html`, `label #kyc-name`, `label #kyc-pan`, `label #kyc-dob`, `label #kyc-mobile`
- Note: Reviewer language "english" is not a BCP-47 code; agent abstains for that rule only.
  - [x] invalid language code -> no html-has-lang proposal
  - [x] other proposals still offered
  - [x] original.html never modified

## PASS - B2 SIP sign-up
`examples/samples/02_sip_signup.html` - Mixed: 3 fixable, 3 unsupported -> manual queue

- Baseline counts: `{'html-has-lang': 1, 'image-alt': 1, 'label': 2, 'link-name': 1, 'select-name': 1}`  ->  Final counts: `{'image-alt': 1, 'link-name': 1, 'select-name': 1}`
- verified: **html-has-lang** `html`  `<html>` -> `<html lang="en">`
- verified: **label** `#sip-name`  `<label>Investor name</label>` -> `<label for="sip-name">Investor name</label>`
- verified: **label** `#sip-amount`  `<label>Monthly amount (₹)</label>` -> `<label for="sip-amount">Monthly amount (₹)</label>`
- Manual-review queue: `image-alt img`, `link-name a`, `select-name #sip-fund`
  - [x] language and labels detected
  - [x] unsupported rules detected (image-alt, link-name, select-name)
  - [x] exactly 3 proposals (language + 2 labels)
  - [x] all patches verified
  - [x] unsupported issues left for manual review, not edited
  - [x] original.html never modified

## PASS - B3 Loan EMI calculator
`examples/samples/03_loan_emi_calculator.html` - Labels fixed; icon-only reset button escalated

- Baseline counts: `{'button-name': 1, 'label': 3}`  ->  Final counts: `{'button-name': 1}`
- verified: **label** `#emi-amount`  `<label>Loan amount (₹)</label>` -> `<label for="emi-amount">Loan amount (₹)</label>`
- verified: **label** `#emi-rate`  `<label>Interest rate (% per year)</label>` -> `<label for="emi-rate">Interest rate (% per year)</label>`
- verified: **label** `#emi-tenure`  `<label>Tenure (months)</label>` -> `<label for="emi-tenure">Tenure (months)</label>`
- Manual-review queue: `button-name #emi-reset`
  - [x] 3 labels and 1 button name detected
  - [x] 3 label proposals only (icon-only reset button is not guessed)
  - [x] labels cleared
  - [x] icon-only button left for manual review
  - [x] original.html never modified

## PASS - B4 Insurance claim
`examples/samples/04_insurance_claim.html` - Claim form fully repaired and verified

- Baseline counts: `{'button-name': 1, 'html-has-lang': 1, 'label': 3}`  ->  Final counts: `{}`
- verified: **button-name** `#submit-claim`  `<span aria-hidden="true">Submit claim</span>` -> `<span>Submit claim</span>`
- verified: **html-has-lang** `html`  `<html>` -> `<html lang="en">`
- verified: **label** `#claim-policy`  `<label>Policy number</label>` -> `<label for="claim-policy">Policy number</label>`
- verified: **label** `#claim-date`  `<label>Date of incident</label>` -> `<label for="claim-date">Date of incident</label>`
- verified: **label** `#claim-amount`  `<label>Estimated claim amount (₹)</label>` -> `<label for="claim-amount">Estimated claim amount (₹)</label>`
  - [x] language, 3 labels, button name detected
  - [x] already-labelled textarea is not touched
  - [x] 5 patches applied, all verified
  - [x] total violations reach 0
  - [x] original.html never modified

## PASS - B5 Payment edge cases
`examples/samples/05_banking_edge_cases.html` - Six near-miss patterns on a payment form; agent must abstain

- Baseline counts: `{'button-name': 3, 'label': 4}`  ->  Final counts: `{'button-name': 3, 'label': 4}`
- Manual-review queue: `button-name #mystery`, `button-name button:nth-child(9)`, `button-name #two-spans`, `label #acct`, `label input[name="ifsc"]`, `label input[name="amount"]`, `label input[name="confirm_amount"]`
  - [x] label and button-name findings detected
  - [x] ZERO proposals (agent abstains on every ambiguous pattern)
  - [x] working file untouched
  - [x] original.html never modified

## PASS - B6 Accessible sign-in
`examples/samples/06_accessible_login.html` - Clean control page; no false positives / edits

  - [x] zero violations on clean page
  - [x] zero proposals
  - [x] original.html never modified

## PASS - B7 Unsafe payment page
`examples/samples/07_unsafe_payment_page.html` - Script + inline handler refused at input

- Note: Refused: Inline event handlers and javascript: URLs are not supported.
  - [x] script/onclick page refused before scan
