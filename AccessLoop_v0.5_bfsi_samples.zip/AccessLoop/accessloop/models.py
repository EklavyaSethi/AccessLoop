from __future__ import annotations
from dataclasses import dataclass, asdict
from collections import Counter
from typing import Any


@dataclass(frozen=True)
class Finding:
    rule_id: str
    selector: str
    impact: str
    help: str
    description: str


@dataclass(frozen=True)
class ScanResult:
    findings: tuple[Finding, ...]
    incomplete: int = 0
    passed_rules: int = 0

    @classmethod
    def from_axe(cls, data: dict[str, Any]) -> 'ScanResult':
        findings = []
        for violation in data.get('violations', []):
            for node in violation.get('nodes', []):
                targets = node.get('target') or ['(unknown element)']
                findings.append(Finding(
                    rule_id=str(violation['id']),
                    selector=str(targets[0]),
                    impact=str(violation.get('impact') or 'unknown'),
                    help=str(violation.get('help') or violation['id']),
                    description=str(node.get('failureSummary') or ''),
                ))
        return cls(tuple(findings), len(data.get('incomplete', [])), len(data.get('passes', [])))

    def counts(self) -> Counter[str]:
        return Counter(f.rule_id for f in self.findings)


@dataclass(frozen=True)
class Proposal:
    proposal_id: str
    rule_id: str
    selector: str
    explanation: str
    evidence: str
    before: str
    after: str
    base_sha256: str
    new_html: str


@dataclass(frozen=True)
class Outcome:
    status: str
    detail: str
    before_count: int
    after_count: int

    def to_dict(self) -> dict:
        return asdict(self)
