"""Explicit state machine with hash checks, reviewer approval and atomic rollback."""
from __future__ import annotations
import json
import os
import re
import tempfile
from dataclasses import asdict
from datetime import datetime, timezone
from pathlib import Path
from typing import Callable
from bs4 import BeautifulSoup
from .models import ScanResult, Proposal, Outcome
from .planner import plan, sha256
from .scanner import scan_html
from .verification import verify

MAX_BYTES = 200 * 1024


class WorkflowError(RuntimeError):
    pass


def validate_source(source: str) -> None:
    if not source.strip() or len(source.encode('utf-8')) > MAX_BYTES:
        raise WorkflowError('Provide a nonempty static HTML file under 200 KB.')
    soup = BeautifulSoup(source, 'html.parser')
    if soup.html is None:
        raise WorkflowError('The input must contain an <html> element.')
    for tag in soup.find_all(True):
        if tag.name in {'script', 'iframe', 'object', 'embed', 'base'}:
            raise WorkflowError('Only static, trusted HTML is supported. Script/iframe/object/embed/base elements are disallowed.')
        for name, val in tag.attrs.items():
            if name.lower().startswith('on') or (isinstance(val, str) and val.strip().lower().startswith('javascript:')):
                raise WorkflowError('Inline event handlers and javascript: URLs are not supported.')


def read_source(path: Path) -> str:
    # Keep CRLF intact when hashing and restoring the working copy.
    with path.open('r', encoding='utf-8', newline='') as handle:
        return handle.read()


def atomic_write(path: Path, content: str) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    fd, tmp = tempfile.mkstemp(prefix='.accessloop_', dir=path.parent)
    try:
        with os.fdopen(fd, 'w', encoding='utf-8', newline='') as handle:
            handle.write(content)
            handle.flush()
            os.fsync(handle.fileno())
        os.replace(tmp, path)
    finally:
        if os.path.exists(tmp):
            os.unlink(tmp)


class Workflow:
    def __init__(self, workspace: Path, scanner: Callable[[str], ScanResult] = scan_html):
        self.workspace = Path(workspace)
        self.scanner = scanner
        self.before: ScanResult | None = None
        self.current_scan: ScanResult | None = None
        self.proposals: tuple[Proposal, ...] = ()
        self.events: list[dict] = []
        self.loaded = False

    @property
    def current_html(self) -> str:
        if not self.loaded:
            raise WorkflowError('Load an HTML file first.')
        return read_source(self.workspace / 'working.html')

    def load(self, source: str) -> None:
        validate_source(source)
        self.workspace.mkdir(parents=True, exist_ok=True)
        atomic_write(self.workspace / 'original.html', source)
        atomic_write(self.workspace / 'working.html', source)
        self.events = []
        self.before = None
        self.current_scan = None
        self.proposals = ()
        self.loaded = True
        self._event('loaded', 'Original saved as a separate immutable-for-session copy.')

    def scan(self, language: str = 'en') -> ScanResult:
        current = self.current_html
        scan_result = self.scanner(current)  # failures propagate; no misleading blank report
        self.current_scan = scan_result
        if self.before is None:
            self.before = scan_result
        self.proposals = plan(current, scan_result.findings, language=language)
        self._event('scanned', f'{len(scan_result.findings)} detected violation nodes; {len(self.proposals)} patch proposals.')
        return scan_result

    def reject(self, proposal_id: str) -> Outcome:
        self._lookup(proposal_id)
        self._event('rejected', proposal_id)
        n = len(self.current_scan.findings) if self.current_scan else -1
        return Outcome('rejected', 'No file modified; rejection recorded.', n, n)

    def apply(self, proposal_id: str, approved: bool = False, language: str = 'en') -> Outcome:
        proposal = self._lookup(proposal_id)
        if not approved:
            return self.reject(proposal_id)
        current = self.current_html
        if sha256(current) != proposal.base_sha256:
            raise WorkflowError('Stale proposal blocked: working file changed after this diff was created.')
        if self.current_scan is None:
            raise WorkflowError('Scan before applying a proposal.')
        # Regenerate patch server-side from the original finding; no LLM-supplied HTML executes here.
        valid = plan(current, self.current_scan.findings, language=language)
        candidate = next((p for p in valid if p.proposal_id == proposal_id), None)
        if candidate is None or candidate.new_html != proposal.new_html:
            raise WorkflowError('Proposal failed restricted-patch validation.')
        previous_scan = self.current_scan
        backup_file = self.workspace / 'backups' / f'{len(self.events):04d}_{sha256(current)[:12]}.html'
        atomic_write(backup_file, current)
        atomic_write(self.workspace / 'working.html', candidate.new_html)
        try:
            after = self.scanner(self.current_html)
            ok, detail = verify(previous_scan, after, candidate.rule_id)
            if not ok:
                raise WorkflowError(detail)
        except Exception as error:
            atomic_write(self.workspace / 'working.html', current)
            self._event('rolled_back', f'{proposal_id}: {error}')
            return Outcome('rolled_back', str(error), len(previous_scan.findings), len(previous_scan.findings))
        self.current_scan = after
        self.proposals = plan(self.current_html, after.findings, language=language)
        self._event('verified', f'{proposal_id}: {detail}')
        return Outcome('verified', detail, len(previous_scan.findings), len(after.findings))

    def reset(self) -> None:
        original = read_source(self.workspace / 'original.html')
        self.load(original)

    def report_json(self) -> str:
        if not self.loaded:
            raise WorkflowError('Load a file first.')
        report = {
            'product': 'AccessLoop',
            'scope': 'Static HTML; automated WCAG rule checks; not a conformance certificate',
            'original_sha256': sha256(read_source(self.workspace / 'original.html')),
            'current_sha256': sha256(self.current_html),
            'baseline_counts': dict(self.before.counts()) if self.before else None,
            'current_counts': dict(self.current_scan.counts()) if self.current_scan else None,
            'unresolved': [asdict(f) for f in self.current_scan.findings] if self.current_scan else [],
            'audit_events': self.events,
        }
        return json.dumps(report, indent=2, ensure_ascii=False)

    def _lookup(self, proposal_id: str) -> Proposal:
        match = next((p for p in self.proposals if p.proposal_id == proposal_id), None)
        if match is None:
            raise WorkflowError('Unknown or expired proposal ID.')
        return match

    def _event(self, status: str, detail: str) -> None:
        self.events.append({
            'timestamp_utc': datetime.now(timezone.utc).isoformat(timespec='seconds'),
            'event': status,
            'detail': detail,
            'working_sha256': sha256(self.current_html) if self.loaded else None,
        })
