"""Runs the actual axe-core browser engine, with zero CDN dependency at runtime."""
from __future__ import annotations
import os
from pathlib import Path
from playwright.sync_api import sync_playwright
from .models import ScanResult

ROOT = Path(__file__).resolve().parent.parent
AXE_PATH = Path(os.environ.get('ACCESSLOOP_AXE_PATH', str(ROOT / 'node_modules/axe-core/axe.min.js')))
TAGS = ['wcag2a', 'wcag2aa', 'wcag21a', 'wcag21aa', 'wcag22a', 'wcag22aa']


class ScanError(RuntimeError):
    pass


def scan_html(html: str) -> ScanResult:
    if not AXE_PATH.is_file():
        raise ScanError('axe-core not installed. Run `npm install` in the project directory first.')
    try:
        with sync_playwright() as playwright:
            launch_args = {'headless': True}
            # Optional override for environments with a system Chromium installation.
            if os.getenv('ACCESSLOOP_CHROMIUM_EXECUTABLE'):
                launch_args['executable_path'] = os.environ['ACCESSLOOP_CHROMIUM_EXECUTABLE']
            browser = playwright.chromium.launch(**launch_args)
            try:
                context = browser.new_context(service_workers='block')
                # Demo accepts trusted static pages. Block all external resource requests.
                context.route('**/*', lambda route: route.abort())
                page = context.new_page()
                page.set_default_timeout(10000)
                page.set_content(html, wait_until='domcontentloaded', timeout=15000)
                page.add_script_tag(path=str(AXE_PATH))
                data = page.evaluate('''async (tags) => {
                    return await window.axe.run(document, {
                        runOnly: { type: 'tag', values: tags },
                        resultTypes: ['violations', 'incomplete', 'passes']
                    });
                }''', TAGS)
                return ScanResult.from_axe(data)
            finally:
                browser.close()
    except ScanError:
        raise
    except Exception as error:
        raise ScanError(f'Browser scan failed: {error}') from error
