"""Restricted, source-preserving edit templates; never executes model-written code."""
from __future__ import annotations
import hashlib
import html as html_std
import re
from collections.abc import Iterator
from bs4 import BeautifulSoup
from .models import Finding, Proposal

HTML_OPEN = re.compile(r'<html\b[^>]*>', re.IGNORECASE)
LABEL_INPUT = re.compile(
    r'(?P<label><label\b(?P<label_attrs>[^>]*)>(?P<label_text>[^<>]+)</label>)'
    r'(?P<space>\s*)'
    r'(?P<input><input\b(?P<input_attrs>[^>]*)>)', re.IGNORECASE
)
BUTTON = re.compile(r'<button\b(?P<attrs>[^>]*)>(?P<body>.*?)</button\s*>', re.IGNORECASE | re.DOTALL)
SINGLE_HIDDEN_SPAN = re.compile(
    r'\s*<span\b(?P<attrs>[^>]*)>(?P<text>[^<>]+)</span>\s*', re.IGNORECASE | re.DOTALL
)
HIDDEN_ATTRIBUTE = re.compile(r'\s+aria-hidden\s*=\s*([\'"])true\1', re.IGNORECASE)
LANG_ATTRIBUTE = re.compile(r'(?<![\w-])lang\s*=', re.IGNORECASE)


def sha256(text: str) -> str:
    return hashlib.sha256(text.encode('utf-8')).hexdigest()


def attr(tag_attrs: str, name: str) -> str | None:
    found = re.search(r'(?<![\w-])' + re.escape(name) + r'\s*=\s*([\'"])(.*?)\1', tag_attrs, re.IGNORECASE | re.DOTALL)
    return html_std.unescape(found.group(2)) if found else None


def exactly_one_id(source: str, target_id: str) -> bool:
    # Restrict the demo engine to ordinary CSS-safe ID tokens.
    if not re.fullmatch(r'[A-Za-z][A-Za-z0-9_-]*', target_id):
        return False
    soup = BeautifulSoup(source, 'html.parser')
    return len(soup.find_all(id=target_id)) == 1


def selector_matches_id(selector: str, target_id: str) -> bool:
    return re.search(r'(?<![\w-])#' + re.escape(target_id) + r'(?![\w-])', selector) is not None


def for_finding(source: str, finding: Finding, language: str = 'en') -> tuple[str, str, str, str, str] | None:
    """Return patched html, old snippet, new snippet, explanation, evidence; else abstain."""
    if finding.rule_id == 'html-has-lang':
        if not re.fullmatch(r'[a-z]{2}(?:-[A-Z]{2})?', language):
            return None
        matches = list(HTML_OPEN.finditer(source))
        if len(matches) != 1 or LANG_ATTRIBUTE.search(matches[0].group()):
            return None
        match = matches[0]
        old = match.group()
        new = old[:-1] + f' lang="{language}">'
        return source[:match.start()] + new + source[match.end():], old, new, 'Declare the document language for screen readers.', f'Language explicitly selected by reviewer: {language}'

    if finding.rule_id == 'label':
        for match in LABEL_INPUT.finditer(source):
            input_id = attr(match.group('input_attrs'), 'id')
            if not input_id or not exactly_one_id(source, input_id):
                continue
            if not selector_matches_id(finding.selector, input_id):
                continue
            if attr(match.group('label_attrs'), 'for') is not None:
                continue
            label = html_std.unescape(match.group('label_text')).strip()
            if len(label) < 2 or len(label) > 80:
                continue
            old = match.group('label')
            new = re.sub(r'^<label\b', f'<label for="{html_std.escape(input_id, quote=True)}"', old, count=1, flags=re.IGNORECASE)
            return (source[:match.start('label')] + new + source[match.end('label'):], old, new,
                    'Associate the existing visible label with the input using its unique ID.',
                    f'Adjacent label text: "{label}"; target input ID: {input_id}')
        return None

    if finding.rule_id == 'button-name':
        for match in BUTTON.finditer(source):
            button_id = attr(match.group('attrs'), 'id')
            if not button_id or not exactly_one_id(source, button_id) or not selector_matches_id(finding.selector, button_id):
                continue
            hidden = SINGLE_HIDDEN_SPAN.fullmatch(match.group('body'))
            if not hidden or not HIDDEN_ATTRIBUTE.search(hidden.group('attrs')):
                continue
            text = html_std.unescape(hidden.group('text')).strip()
            if not 2 <= len(text) <= 80:
                continue
            old = match.group('body')
            new = HIDDEN_ATTRIBUTE.sub('', old, count=1)
            return (source[:match.start('body')] + new + source[match.end('body'):], old.strip(), new.strip(),
                    'Expose the button’s existing visible text to assistive technology.',
                    f'Button #{button_id} already shows "{text}" but incorrectly hides it from the accessibility tree.')
        return None
    return None


def plan(source: str, findings: tuple[Finding, ...], language: str = 'en') -> tuple[Proposal, ...]:
    proposals: list[Proposal] = []
    for index, finding in enumerate(findings):
        patch = for_finding(source, finding, language=language)
        if patch is None:
            continue
        new_source, before, after, why, evidence = patch
        if new_source == source:
            continue
        proposals.append(Proposal(
            proposal_id=f'{sha256(source)[:10]}-{index}-{finding.rule_id}',
            rule_id=finding.rule_id, selector=finding.selector,
            explanation=why, evidence=evidence,
            before=before, after=after, base_sha256=sha256(source), new_html=new_source,
        ))
    return tuple(proposals)
